# Nikah Sunnah

Plateforme matrimoniale islamique complète — Next.js 14 (App Router) + TypeScript + Tailwind + Supabase + Stripe.

## ✅ Fonctionnalités livrées

- Inscription Homme / Femme séparée, validation Zod
- Connexion sécurisée, mot de passe oublié, vérification email (Supabase Auth)
- Tableau de bord utilisateur (stats, suggestions, statut du profil)
- Recherche de profils avec filtres (ville, âge), boost effectif pris en compte
- Profil détaillé + édition (repasse en modération à chaque modification)
- Favoris, Signalement (5 motifs)
- **Messagerie halal** : une seule conversation active à la fois, clôture
  définitive, historique conservé, 3 messages/jour en gratuit / illimité en
  Premium — règles appliquées **en base de données** (triggers), pas
  seulement côté app
- **Panneau admin** : vue d'ensemble, validation des profils, gestion des
  utilisateurs (bannir/suspendre/réactiver), signalements, abonnements,
  journal d'audit (`admin_actions`)
- **Stripe** : abonnement Premium 12,99 €/mois, Boost profil 4,99 €/7 jours,
  webhook de synchronisation
- SEO : sitemap.xml, robots.txt, Open Graph
- Script de données de démonstration

## 🚀 Démarrage

### 1. Installer les dépendances
```bash
npm install
```

### 2. Créer un projet Supabase
Sur https://supabase.com (gratuit) → copier `.env.example` vers `.env.local`
et renseigner :
- `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`,
  `SUPABASE_SERVICE_ROLE_KEY` (Project Settings > API)

### 3. Appliquer le schéma SQL
Dans Supabase > SQL Editor, exécuter **dans l'ordre** :
1. `supabase/migrations/0001_initial_schema.sql`
2. `supabase/migrations/0002_messagerie_halal.sql`
3. `supabase/migrations/0003_admin_actions.sql`

### 4. Activer la confirmation email
Supabase > Authentication > Providers > Email → laisser "Confirm email" activé.
Authentication > URL Configuration → ajouter `http://localhost:3000/api/auth/confirm`
(et votre domaine de prod) aux Redirect URLs.

### 5. Activer le Realtime sur les messages
Database > Replication → activer la réplication sur la table `messages`
(nécessaire pour l'affichage en direct des nouveaux messages).

### 6. Configurer Stripe
1. Créer un compte sur https://dashboard.stripe.com
2. Créer un produit "Premium" → prix récurrent mensuel **12,99 €** → copier
   le `price_id` dans `STRIPE_PRICE_ID_PREMIUM_MONTHLY`
3. Créer un produit "Boost" → prix unique **4,99 €** → copier le `price_id`
   dans `STRIPE_PRICE_ID_BOOST`
4. Renseigner `STRIPE_SECRET_KEY` et `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
   (Developers > API keys)
5. En local, utiliser la CLI Stripe pour le webhook :
   ```bash
   stripe listen --forward-to localhost:3000/api/stripe/webhook
   ```
   copier le `whsec_...` affiché dans `STRIPE_WEBHOOK_SECRET`.
   En production, créer le endpoint webhook dans le dashboard Stripe vers
   `https://votre-domaine.com/api/stripe/webhook` (événements :
   `checkout.session.completed`, `customer.subscription.updated`,
   `customer.subscription.deleted`).

### 7. Lancer le serveur
```bash
npm run dev
```
→ http://localhost:3000

### 8. (Optionnel) Données de démonstration
```bash
npm run seed
```
Crée 4 comptes de test (1 admin, 2 profils approuvés, 1 en attente). Mot de
passe affiché dans la console. **Ne jamais lancer ce script en production.**

## 🔑 Créer votre premier compte administrateur (méthode sécurisée)

Aucun compte admin n'est codé en dur dans le projet (mauvaise pratique de
sécurité). Pour désigner un admin :
1. Inscrivez-vous normalement sur le site avec votre email.
2. Dans Supabase > SQL Editor :
   ```sql
   update public.users set role = 'admin' where email = 'votre@email.com';
   ```
3. Reconnectez-vous : `/admin` est maintenant accessible.

## ☁️ Déploiement Vercel

1. Poussez le projet sur GitHub (voir plus bas)
2. Sur https://vercel.com → "New Project" → importez le dépôt
3. Renseignez toutes les variables de `.env.example` dans Vercel > Settings
   > Environment Variables (avec vos vraies valeurs de production)
4. Mettez à jour `NEXT_PUBLIC_SITE_URL` avec votre domaine Vercel
5. Déployez. Pensez à mettre à jour les Redirect URLs Supabase et le
   webhook Stripe avec l'URL de production.

## 📦 Pousser ce projet sur GitHub

```bash
cd nikah-sunnah
git init
git add .
git commit -m "Initial commit — Nikah Sunnah"
git branch -M main
git remote add origin https://github.com/VOTRE-COMPTE/nikah-sunnah.git
git push -u origin main
```
(Créez d'abord un dépôt vide sur https://github.com/new — sans README, pour
éviter un conflit avec ce commit initial.)

## 🗂️ Schéma de base de données

8 tables principales : `users`, `profiles`, `conversations`, `messages`,
`subscriptions`, `boosts`, `reports`, `favorites` + `admin_actions` (audit).
RLS activée partout, triggers pour : création auto du compte, vérification
email, anti-triche modération/boost, immuabilité des messages, règle de
conversation unique, limite quotidienne de messages.

## ⚠️ À faire avant la mise en production

- Faire relire `mentions-legales`, `politique-confidentialite` et `cgu`
  (modèles fournis) par un professionnel du droit — le site traite des
  données sensibles RGPD (convictions religieuses)
- Brancher un vrai service d'envoi d'email pour `/api/contact` (ex. Resend)
- Mettre en place l'upload de photos via Supabase Storage (actuellement le
  champ `photo_url` attend une URL ; un composant d'upload reste à
  brancher sur un bucket Storage)
- Envisager `pg_cron` (extension Supabase) pour désactiver automatiquement
  `is_boosted` à l'expiration (actuellement vérifié à la volée côté
  requêtes, ce qui fonctionne mais ne "nettoie" pas la colonne)

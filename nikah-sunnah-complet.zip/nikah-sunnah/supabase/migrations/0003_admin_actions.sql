-- =============================================================================
-- NIKAH SUNNAH — Migration 3 : journal des actions administrateur
-- Fichier : supabase/migrations/0003_admin_actions.sql
-- =============================================================================

create table public.admin_actions (
  id           uuid primary key default gen_random_uuid(),
  admin_id     uuid not null references public.users (id) on delete cascade,
  action_type  text not null, -- ex : 'profile_approved', 'user_banned', 'report_dismissed'
  target_table text not null, -- ex : 'profiles', 'users', 'reports'
  target_id    uuid not null,
  details      jsonb,
  created_at   timestamptz not null default now()
);

create index admin_actions_admin_idx  on public.admin_actions (admin_id);
create index admin_actions_target_idx on public.admin_actions (target_table, target_id);

alter table public.admin_actions enable row level security;

create policy "admin_actions_select_admin" on public.admin_actions
  for select using (public.is_admin());

create policy "admin_actions_insert_admin" on public.admin_actions
  for insert with check (public.is_admin() and admin_id = auth.uid());

grant select, insert on public.admin_actions to authenticated;

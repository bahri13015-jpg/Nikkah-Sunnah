-- =============================================================================
-- NIKAH SUNNAH — Schéma initial complet
-- Fichier : supabase/migrations/0001_initial_schema.sql
-- À exécuter via : supabase db push   (ou collé dans Supabase > SQL Editor)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 0. EXTENSIONS
-- -----------------------------------------------------------------------------
create extension if not exists pgcrypto; -- gen_random_uuid()

-- -----------------------------------------------------------------------------
-- 1. TYPES ÉNUMÉRÉS
-- -----------------------------------------------------------------------------
create type public.user_role        as enum ('user', 'admin');
create type public.user_status      as enum ('pending_verification', 'active', 'suspended', 'banned');
create type public.gender_type      as enum ('homme', 'femme');
create type public.profile_status   as enum ('pending', 'approved', 'rejected');
create type public.subscription_plan   as enum ('free', 'premium');
create type public.subscription_status as enum ('active', 'canceled', 'past_due', 'incomplete');
create type public.boost_status     as enum ('active', 'expired');
create type public.report_status    as enum ('pending', 'reviewed', 'actioned', 'dismissed');

-- -----------------------------------------------------------------------------
-- 2. TABLE : users (miroir applicatif de auth.users)
-- -----------------------------------------------------------------------------
create table public.users (
  id               uuid primary key references auth.users (id) on delete cascade,
  email            text not null,
  role             public.user_role not null default 'user',
  status           public.user_status not null default 'pending_verification',
  email_verified_at timestamptz,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

comment on table public.users is 'Compte applicatif : rôle, statut de modération, vérification email. 1-1 avec auth.users.';

-- -----------------------------------------------------------------------------
-- 3. TABLE : profiles (fiche matrimoniale)
-- -----------------------------------------------------------------------------
create table public.profiles (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null unique references public.users (id) on delete cascade,
  gender              public.gender_type not null,
  first_name          text not null,
  birth_date          date not null,
  city                text,
  country             text default 'France',
  profession          text,
  education_level     text,
  religious_practice  text,   -- ex : "pratiquant(e)", niveau de pratique déclaré
  marital_status      text,   -- célibataire / divorcé(e) / veuf / veuve
  has_children        boolean not null default false,
  wants_children      text,
  bio                 text,
  looking_for         text,   -- description du profil recherché
  photo_url           text,
  status              public.profile_status not null default 'pending',
  rejection_reason    text,
  is_boosted          boolean not null default false,
  boosted_until       timestamptz,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),

  constraint chk_profile_adult check (birth_date <= (current_date - interval '18 years')::date)
);

comment on table public.profiles is 'Fiche matrimoniale publique. status contrôle la visibilité (modération admin).';

-- -----------------------------------------------------------------------------
-- 4. TABLE : conversations
-- -----------------------------------------------------------------------------
create table public.conversations (
  id               uuid primary key default gen_random_uuid(),
  user1_id         uuid not null references public.users (id) on delete cascade,
  user2_id         uuid not null references public.users (id) on delete cascade,
  created_at       timestamptz not null default now(),
  last_message_at  timestamptz,

  constraint chk_conversation_distinct_users check (user1_id <> user2_id)
);

-- empêche les doublons (A,B) / (B,A)
create unique index conversations_unique_pair_idx
  on public.conversations (least(user1_id, user2_id), greatest(user1_id, user2_id));

-- -----------------------------------------------------------------------------
-- 5. TABLE : messages
-- -----------------------------------------------------------------------------
create table public.messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  sender_id       uuid not null references public.users (id) on delete cascade,
  content         text not null check (char_length(content) between 1 and 4000),
  read_at         timestamptz,
  created_at      timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- 6. TABLE : subscriptions (abonnements)
-- -----------------------------------------------------------------------------
create table public.subscriptions (
  id                      uuid primary key default gen_random_uuid(),
  user_id                 uuid not null references public.users (id) on delete cascade,
  plan                    public.subscription_plan not null default 'free',
  status                  public.subscription_status not null default 'active',
  stripe_customer_id      text,
  stripe_subscription_id  text unique,
  current_period_end      timestamptz,
  cancel_at_period_end    boolean not null default false,
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- 7. TABLE : boosts (mise en avant de profil, paiement à l'unité)
-- -----------------------------------------------------------------------------
create table public.boosts (
  id                        uuid primary key default gen_random_uuid(),
  user_id                   uuid not null references public.users (id) on delete cascade,
  stripe_payment_intent_id  text,
  status                    public.boost_status not null default 'active',
  started_at                timestamptz not null default now(),
  ends_at                   timestamptz not null,
  created_at                timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- 8. TABLE : reports (signalements)
-- -----------------------------------------------------------------------------
create table public.reports (
  id                 uuid primary key default gen_random_uuid(),
  reporter_id        uuid not null references public.users (id) on delete cascade,
  reported_user_id   uuid not null references public.users (id) on delete cascade,
  reason             text not null,
  description        text,
  status             public.report_status not null default 'pending',
  reviewed_by        uuid references public.users (id),
  reviewed_at        timestamptz,
  created_at         timestamptz not null default now(),

  constraint chk_report_distinct_users check (reporter_id <> reported_user_id)
);

-- -----------------------------------------------------------------------------
-- 9. TABLE : favorites
-- -----------------------------------------------------------------------------
create table public.favorites (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null references public.users (id) on delete cascade,
  favorited_user_id  uuid not null references public.users (id) on delete cascade,
  created_at         timestamptz not null default now(),

  constraint chk_favorite_distinct_users check (user_id <> favorited_user_id),
  constraint uq_favorite unique (user_id, favorited_user_id)
);

-- -----------------------------------------------------------------------------
-- 10. INDEX
-- -----------------------------------------------------------------------------
create index profiles_gender_status_idx on public.profiles (gender, status);
create index profiles_user_id_idx       on public.profiles (user_id);
create index conversations_user1_idx    on public.conversations (user1_id);
create index conversations_user2_idx    on public.conversations (user2_id);
create index messages_conversation_idx  on public.messages (conversation_id, created_at);
create index reports_reported_user_idx  on public.reports (reported_user_id);
create index favorites_user_idx         on public.favorites (user_id);
create index subscriptions_user_idx     on public.subscriptions (user_id);
create index boosts_user_idx            on public.boosts (user_id);

-- -----------------------------------------------------------------------------
-- 11. FONCTIONS UTILITAIRES
-- -----------------------------------------------------------------------------

-- Vérifie si l'utilisateur connecté est admin (SECURITY DEFINER pour éviter
-- toute récursion RLS sur public.users).
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.users
    where id = auth.uid() and role = 'admin'
  );
$$;

-- Met à jour updated_at automatiquement.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- Crée la ligne public.users à l'inscription (déclenché sur auth.users).
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users (id, email, status)
  values (new.id, new.email, 'pending_verification');
  return new;
end;
$$;

-- Passe le compte en "active" dès que Supabase confirme l'email
-- (auth.users.email_confirmed_at renseigné par le lien de vérification).
create or replace function public.handle_email_verified()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.email_confirmed_at is not null and old.email_confirmed_at is null then
    update public.users
    set status = 'active', email_verified_at = new.email_confirmed_at
    where id = new.id and status = 'pending_verification';
  end if;
  return new;
end;
$$;

-- Empêche un utilisateur normal de s'auto-valider, se booster ou
-- modifier la raison de rejet ; repasse le profil en "pending" s'il
-- était déjà approuvé et qu'il le modifie (ré-modération nécessaire).
create or replace function public.protect_profile_moderation_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  is_privileged boolean;
begin
  is_privileged := (auth.role() = 'service_role') or public.is_admin();

  if not is_privileged then
    new.is_boosted       := old.is_boosted;
    new.boosted_until    := old.boosted_until;
    new.rejection_reason := old.rejection_reason;

    if old.status = 'approved' then
      new.status := 'pending';
    else
      new.status := old.status;
    end if;
  end if;

  return new;
end;
$$;

-- Empêche la modification du contenu d'un message après envoi
-- (seul read_at peut changer, pour les accusés de lecture).
create or replace function public.protect_message_content()
returns trigger
language plpgsql
as $$
begin
  if new.content <> old.content
     or new.sender_id <> old.sender_id
     or new.conversation_id <> old.conversation_id then
    raise exception 'Un message envoyé ne peut pas être modifié.';
  end if;
  return new;
end;
$$;

-- Met à jour conversations.last_message_at à chaque nouveau message.
create or replace function public.touch_conversation_last_message()
returns trigger
language plpgsql
as $$
begin
  update public.conversations
  set last_message_at = new.created_at
  where id = new.conversation_id;
  return new;
end;
$$;

-- -----------------------------------------------------------------------------
-- 12. TRIGGERS
-- -----------------------------------------------------------------------------
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create trigger on_auth_user_email_verified
  after update on auth.users
  for each row execute function public.handle_email_verified();

create trigger set_updated_at_users
  before update on public.users
  for each row execute function public.set_updated_at();

create trigger set_updated_at_profiles
  before update on public.profiles
  for each row execute function public.set_updated_at();

create trigger set_updated_at_subscriptions
  before update on public.subscriptions
  for each row execute function public.set_updated_at();

create trigger before_profile_update
  before update on public.profiles
  for each row execute function public.protect_profile_moderation_fields();

create trigger before_message_update
  before update on public.messages
  for each row execute function public.protect_message_content();

create trigger on_message_created
  after insert on public.messages
  for each row execute function public.touch_conversation_last_message();

-- -----------------------------------------------------------------------------
-- 13. ROW LEVEL SECURITY
-- -----------------------------------------------------------------------------
alter table public.users         enable row level security;
alter table public.profiles      enable row level security;
alter table public.conversations enable row level security;
alter table public.messages      enable row level security;
alter table public.subscriptions enable row level security;
alter table public.boosts        enable row level security;
alter table public.reports       enable row level security;
alter table public.favorites     enable row level security;

-- USERS ------------------------------------------------------------------
create policy "users_select_own" on public.users
  for select using (id = auth.uid());

create policy "users_select_admin" on public.users
  for select using (public.is_admin());

create policy "users_update_admin" on public.users
  for update using (public.is_admin()) with check (public.is_admin());

-- PROFILES -----------------------------------------------------------------
create policy "profiles_select_approved" on public.profiles
  for select to authenticated using (status = 'approved');

create policy "profiles_select_own" on public.profiles
  for select using (user_id = auth.uid());

create policy "profiles_select_admin" on public.profiles
  for select using (public.is_admin());

create policy "profiles_insert_own" on public.profiles
  for insert with check (user_id = auth.uid());

create policy "profiles_update_own" on public.profiles
  for update using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "profiles_update_admin" on public.profiles
  for update using (public.is_admin()) with check (public.is_admin());

-- CONVERSATIONS --------------------------------------------------------------
create policy "conversations_select_participant" on public.conversations
  for select using (auth.uid() in (user1_id, user2_id) or public.is_admin());

create policy "conversations_insert_participant" on public.conversations
  for insert with check (auth.uid() in (user1_id, user2_id));

-- MESSAGES -------------------------------------------------------------------
create policy "messages_select_participant" on public.messages
  for select using (
    public.is_admin()
    or exists (
      select 1 from public.conversations c
      where c.id = conversation_id and auth.uid() in (c.user1_id, c.user2_id)
    )
  );

create policy "messages_insert_participant" on public.messages
  for insert with check (
    sender_id = auth.uid()
    and exists (
      select 1 from public.conversations c
      where c.id = conversation_id and auth.uid() in (c.user1_id, c.user2_id)
    )
  );

create policy "messages_update_participant" on public.messages
  for update using (
    exists (
      select 1 from public.conversations c
      where c.id = conversation_id and auth.uid() in (c.user1_id, c.user2_id)
    )
  );

-- SUBSCRIPTIONS ----------------------------------------------------------------
create policy "subscriptions_select_own" on public.subscriptions
  for select using (user_id = auth.uid() or public.is_admin());

create policy "subscriptions_update_admin" on public.subscriptions
  for update using (public.is_admin()) with check (public.is_admin());
-- Pas de policy insert/update pour les utilisateurs : les écritures se
-- font via le webhook Stripe avec la clé service_role (bypass RLS).

-- BOOSTS -------------------------------------------------------------------
create policy "boosts_select_own" on public.boosts
  for select using (user_id = auth.uid() or public.is_admin());

-- REPORTS ------------------------------------------------------------------
create policy "reports_select_own_or_admin" on public.reports
  for select using (reporter_id = auth.uid() or public.is_admin());

create policy "reports_insert_own" on public.reports
  for insert with check (reporter_id = auth.uid());

create policy "reports_update_admin" on public.reports
  for update using (public.is_admin()) with check (public.is_admin());

-- FAVORITES ------------------------------------------------------------------
create policy "favorites_select_own" on public.favorites
  for select using (user_id = auth.uid());

create policy "favorites_insert_own" on public.favorites
  for insert with check (user_id = auth.uid());

create policy "favorites_delete_own" on public.favorites
  for delete using (user_id = auth.uid());

-- -----------------------------------------------------------------------------
-- 14. GRANTS (par défaut Supabase configure déjà ceci, ajouté pour portabilité)
-- -----------------------------------------------------------------------------
grant usage on schema public to anon, authenticated, service_role;

grant select, insert, update, delete on
  public.users, public.profiles, public.conversations, public.messages,
  public.subscriptions, public.boosts, public.reports, public.favorites
to authenticated;

grant all on all tables in schema public to service_role;

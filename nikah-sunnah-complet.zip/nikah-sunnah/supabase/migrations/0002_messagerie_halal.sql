-- =============================================================================
-- NIKAH SUNNAH — Migration 2 : messagerie halal
-- Fichier : supabase/migrations/0002_messagerie_halal.sql
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. Statut de conversation (active / clôturée)
-- -----------------------------------------------------------------------------
create type public.conversation_status as enum ('active', 'closed');

alter table public.conversations
  add column status public.conversation_status not null default 'active',
  add column closed_at timestamptz,
  add column closed_by uuid references public.users (id);

-- -----------------------------------------------------------------------------
-- 2. Règle : un utilisateur ne peut avoir qu'UNE SEULE conversation active
-- -----------------------------------------------------------------------------
create or replace function public.enforce_single_active_conversation()
returns trigger
language plpgsql
as $$
begin
  if new.status = 'active' then
    if exists (
      select 1 from public.conversations
      where status = 'active'
        and (user1_id in (new.user1_id, new.user2_id)
             or user2_id in (new.user1_id, new.user2_id))
    ) then
      raise exception
        'Une conversation active existe déjà pour l''un des deux utilisateurs. Elle doit être clôturée avant d''en commencer une nouvelle.';
    end if;
  end if;
  return new;
end;
$$;

create trigger before_conversation_insert
  before insert on public.conversations
  for each row execute function public.enforce_single_active_conversation();

-- Empêche de changer les participants ou de rouvrir une conversation clôturée.
create or replace function public.protect_conversation_update()
returns trigger
language plpgsql
as $$
begin
  if new.user1_id <> old.user1_id or new.user2_id <> old.user2_id then
    raise exception 'Les participants d''une conversation ne peuvent pas être modifiés.';
  end if;
  if old.status = 'closed' and new.status = 'active' then
    raise exception 'Une conversation clôturée ne peut pas être réactivée.';
  end if;
  return new;
end;
$$;

create trigger before_conversation_update
  before update on public.conversations
  for each row execute function public.protect_conversation_update();

-- Autorise les deux participants (ou un admin) à clôturer leur conversation.
create policy "conversations_update_participant" on public.conversations
  for update
  using (auth.uid() in (user1_id, user2_id) or public.is_admin())
  with check (auth.uid() in (user1_id, user2_id) or public.is_admin());

-- -----------------------------------------------------------------------------
-- 3. Impossible d'écrire dans une conversation clôturée
-- -----------------------------------------------------------------------------
create or replace function public.prevent_message_in_closed_conversation()
returns trigger
language plpgsql
as $$
begin
  if exists (
    select 1 from public.conversations
    where id = new.conversation_id and status = 'closed'
  ) then
    raise exception 'Cette conversation est clôturée, vous ne pouvez plus y écrire.';
  end if;
  return new;
end;
$$;

create trigger before_message_insert_check_conversation
  before insert on public.messages
  for each row execute function public.prevent_message_in_closed_conversation();

-- -----------------------------------------------------------------------------
-- 4. Limite de 3 messages/jour pour les comptes gratuits (Premium = illimité)
-- -----------------------------------------------------------------------------
create or replace function public.enforce_daily_message_limit()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  is_premium boolean;
  messages_today integer;
begin
  select exists (
    select 1 from public.subscriptions
    where user_id = new.sender_id and plan = 'premium' and status = 'active'
  ) into is_premium;

  if is_premium then
    return new;
  end if;

  select count(*) into messages_today
  from public.messages
  where sender_id = new.sender_id
    and created_at >= date_trunc('day', now());

  if messages_today >= 3 then
    raise exception
      'Limite de 3 messages par jour atteinte pour les comptes gratuits. Passez en Premium pour un nombre illimité de messages.';
  end if;

  return new;
end;
$$;

create trigger before_message_insert_check_daily_limit
  before insert on public.messages
  for each row execute function public.enforce_daily_message_limit();

-- -----------------------------------------------------------------------------
-- 5. Index
-- -----------------------------------------------------------------------------
create index conversations_status_idx on public.conversations (status);

/**
 * Crée des comptes de démonstration (utilisateurs + profils) pour tester
 * l'application en local.
 *
 * Utilise l'API Admin de Supabase (createUser confirme l'email directement,
 * ce qui est nécessaire car on ne peut pas écrire dans auth.users en SQL
 * brut — les mots de passe doivent être hashés par GoTrue).
 *
 * Lancement :
 *   npm run seed
 *
 * Nécessite dans .env.local :
 *   NEXT_PUBLIC_SUPABASE_URL
 *   SUPABASE_SERVICE_ROLE_KEY
 */
import { createClient } from "@supabase/supabase-js";
import * as dotenv from "dotenv";

dotenv.config({ path: ".env.local" });

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!url || !serviceKey) {
  console.error(
    "❌ NEXT_PUBLIC_SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont requis dans .env.local"
  );
  process.exit(1);
}

const supabase = createClient(url, serviceKey, {
  auth: { autoConfirm: true },
});

const DEMO_PASSWORD = "DemoNikah2026!"; // ⚠️ à usage local/démo uniquement

type DemoProfile = {
  email: string;
  gender: "homme" | "femme";
  first_name: string;
  birth_date: string;
  city: string;
  country: string;
  bio: string;
  status: "pending" | "approved" | "rejected";
  isAdmin?: boolean;
};

const demoProfiles: DemoProfile[] = [
  {
    email: "admin@nikah-sunnah.test",
    gender: "homme",
    first_name: "Admin",
    birth_date: "1990-01-01",
    city: "Paris",
    country: "France",
    bio: "Compte administrateur de démonstration.",
    status: "approved",
    isAdmin: true,
  },
  {
    email: "yusuf.demo@nikah-sunnah.test",
    gender: "homme",
    first_name: "Yusuf",
    birth_date: "1994-03-12",
    city: "Lyon",
    country: "France",
    bio: "Pratiquant, sérieux, à la recherche d'une épouse pour fonder un foyer.",
    status: "approved",
  },
  {
    email: "amina.demo@nikah-sunnah.test",
    gender: "femme",
    first_name: "Amina",
    birth_date: "1996-07-22",
    city: "Bruxelles",
    country: "Belgique",
    bio: "Pratiquante, douce et déterminée, recherche un époux pieux et bienveillant.",
    status: "approved",
  },
  {
    email: "khadija.demo@nikah-sunnah.test",
    gender: "femme",
    first_name: "Khadija",
    birth_date: "1998-11-05",
    city: "Montréal",
    country: "Canada",
    bio: "Profil en attente de validation pour tester le panneau admin.",
    status: "pending",
  },
];

async function main() {
  for (const p of demoProfiles) {
    const { data: created, error: createError } =
      await supabase.auth.admin.createUser({
        email: p.email,
        password: DEMO_PASSWORD,
        email_confirm: true,
      });

    if (createError || !created.user) {
      console.error(`❌ ${p.email} :`, createError?.message);
      continue;
    }

    const userId = created.user.id;

    // Le trigger handle_new_user a déjà créé la ligne public.users.
    await supabase
      .from("users")
      .update({
        status: "active",
        role: p.isAdmin ? "admin" : "user",
        email_verified_at: new Date().toISOString(),
      })
      .eq("id", userId);

    await supabase.from("profiles").insert({
      user_id: userId,
      gender: p.gender,
      first_name: p.first_name,
      birth_date: p.birth_date,
      city: p.city,
      country: p.country,
      bio: p.bio,
      status: p.status,
    });

    console.log(`✓ ${p.email} (${p.isAdmin ? "admin" : p.gender}) créé`);
  }

  console.log(`\nMot de passe pour tous les comptes de démo : ${DEMO_PASSWORD}`);
  console.log("⚠️  Ne jamais utiliser ce script ou ce mot de passe en production.");
}

main();

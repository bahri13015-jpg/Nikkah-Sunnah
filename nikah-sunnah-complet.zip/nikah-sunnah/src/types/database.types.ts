/**
 * Types Supabase pour le projet.
 *
 * Ce fichier est écrit à la main pour correspondre exactement à
 * supabase/migrations/0001_initial_schema.sql. Une fois le projet Supabase
 * lié en CLI, tu peux le régénérer automatiquement et écraser ce fichier :
 *
 *   npx supabase gen types typescript --project-id <ton-project-id> > src/types/database.types.ts
 */

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type UserRole = "user" | "admin";
export type UserStatus = "pending_verification" | "active" | "suspended" | "banned";
export type GenderType = "homme" | "femme";
export type ProfileStatus = "pending" | "approved" | "rejected";
export type SubscriptionPlan = "free" | "premium";
export type SubscriptionStatus = "active" | "canceled" | "past_due" | "incomplete";
export type BoostStatus = "active" | "expired";
export type ReportStatus = "pending" | "reviewed" | "actioned" | "dismissed";
export type ConversationStatus = "active" | "closed";

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          email: string;
          role: UserRole;
          status: UserStatus;
          email_verified_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          role?: UserRole;
          status?: UserStatus;
          email_verified_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["users"]["Insert"]>;
      };
      profiles: {
        Row: {
          id: string;
          user_id: string;
          gender: GenderType;
          first_name: string;
          birth_date: string;
          city: string | null;
          country: string | null;
          profession: string | null;
          education_level: string | null;
          religious_practice: string | null;
          marital_status: string | null;
          has_children: boolean;
          wants_children: string | null;
          bio: string | null;
          looking_for: string | null;
          photo_url: string | null;
          status: ProfileStatus;
          rejection_reason: string | null;
          is_boosted: boolean;
          boosted_until: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          gender: GenderType;
          first_name: string;
          birth_date: string;
          city?: string | null;
          country?: string | null;
          profession?: string | null;
          education_level?: string | null;
          religious_practice?: string | null;
          marital_status?: string | null;
          has_children?: boolean;
          wants_children?: string | null;
          bio?: string | null;
          looking_for?: string | null;
          photo_url?: string | null;
          status?: ProfileStatus;
          rejection_reason?: string | null;
          is_boosted?: boolean;
          boosted_until?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["profiles"]["Insert"]>;
      };
      conversations: {
        Row: {
          id: string;
          user1_id: string;
          user2_id: string;
          status: ConversationStatus;
          closed_at: string | null;
          closed_by: string | null;
          created_at: string;
          last_message_at: string | null;
        };
        Insert: {
          id?: string;
          user1_id: string;
          user2_id: string;
          status?: ConversationStatus;
          closed_at?: string | null;
          closed_by?: string | null;
          created_at?: string;
          last_message_at?: string | null;
        };
        Update: Partial<Database["public"]["Tables"]["conversations"]["Insert"]>;
      };
      messages: {
        Row: {
          id: string;
          conversation_id: string;
          sender_id: string;
          content: string;
          read_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          conversation_id: string;
          sender_id: string;
          content: string;
          read_at?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["messages"]["Insert"]>;
      };
      subscriptions: {
        Row: {
          id: string;
          user_id: string;
          plan: SubscriptionPlan;
          status: SubscriptionStatus;
          stripe_customer_id: string | null;
          stripe_subscription_id: string | null;
          current_period_end: string | null;
          cancel_at_period_end: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          plan?: SubscriptionPlan;
          status?: SubscriptionStatus;
          stripe_customer_id?: string | null;
          stripe_subscription_id?: string | null;
          current_period_end?: string | null;
          cancel_at_period_end?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["subscriptions"]["Insert"]>;
      };
      boosts: {
        Row: {
          id: string;
          user_id: string;
          stripe_payment_intent_id: string | null;
          status: BoostStatus;
          started_at: string;
          ends_at: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          stripe_payment_intent_id?: string | null;
          status?: BoostStatus;
          started_at?: string;
          ends_at: string;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["boosts"]["Insert"]>;
      };
      reports: {
        Row: {
          id: string;
          reporter_id: string;
          reported_user_id: string;
          reason: string;
          description: string | null;
          status: ReportStatus;
          reviewed_by: string | null;
          reviewed_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          reporter_id: string;
          reported_user_id: string;
          reason: string;
          description?: string | null;
          status?: ReportStatus;
          reviewed_by?: string | null;
          reviewed_at?: string | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["reports"]["Insert"]>;
      };
      favorites: {
        Row: {
          id: string;
          user_id: string;
          favorited_user_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          favorited_user_id: string;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["favorites"]["Insert"]>;
      };
      admin_actions: {
        Row: {
          id: string;
          admin_id: string;
          action_type: string;
          target_table: string;
          target_id: string;
          details: Json | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          admin_id: string;
          action_type: string;
          target_table: string;
          target_id: string;
          details?: Json | null;
          created_at?: string;
        };
        Update: Partial<Database["public"]["Tables"]["admin_actions"]["Insert"]>;
      };
    };
    Views: Record<string, never>;
    Functions: {
      is_admin: {
        Args: Record<string, never>;
        Returns: boolean;
      };
    };
    Enums: {
      user_role: UserRole;
      user_status: UserStatus;
      gender_type: GenderType;
      profile_status: ProfileStatus;
      subscription_plan: SubscriptionPlan;
      subscription_status: SubscriptionStatus;
      boost_status: BoostStatus;
      report_status: ReportStatus;
      conversation_status: ConversationStatus;
    };
  };
}

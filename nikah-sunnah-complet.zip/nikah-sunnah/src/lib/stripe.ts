import Stripe from "stripe";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
  typescript: true,
});

/** Durée du boost en jours — facilement ajustable. */
export const BOOST_DURATION_DAYS = 7;

import { z } from "zod";

const eighteenYearsAgo = () => {
  const d = new Date();
  d.setFullYear(d.getFullYear() - 18);
  return d;
};

export const genderSchema = z.enum(["homme", "femme"], {
  errorMap: () => ({ message: "Genre invalide." }),
});

export const registerSchema = z
  .object({
    gender: genderSchema,
    firstName: z
      .string()
      .min(2, "Le prénom doit contenir au moins 2 caractères.")
      .max(50, "Le prénom est trop long."),
    birthDate: z
      .string()
      .refine((val) => !Number.isNaN(Date.parse(val)), "Date invalide.")
      .refine(
        (val) => new Date(val) <= eighteenYearsAgo(),
        "Vous devez avoir au moins 18 ans pour vous inscrire."
      ),
    city: z.string().min(2, "Ville requise.").max(100),
    country: z.string().min(2, "Pays requis.").max(100).default("France"),
    email: z.string().email("Adresse email invalide."),
    password: z
      .string()
      .min(8, "Le mot de passe doit contenir au moins 8 caractères.")
      .regex(/[A-Z]/, "Le mot de passe doit contenir au moins une majuscule.")
      .regex(/[0-9]/, "Le mot de passe doit contenir au moins un chiffre."),
    confirmPassword: z.string(),
    acceptTerms: z.literal(true, {
      errorMap: () => ({ message: "Vous devez accepter les CGU." }),
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Les mots de passe ne correspondent pas.",
    path: ["confirmPassword"],
  });

export type RegisterInput = z.infer<typeof registerSchema>;

export const loginSchema = z.object({
  email: z.string().email("Adresse email invalide."),
  password: z.string().min(1, "Mot de passe requis."),
});

export type LoginInput = z.infer<typeof loginSchema>;

export const forgotPasswordSchema = z.object({
  email: z.string().email("Adresse email invalide."),
});

export const profileUpdateSchema = z.object({
  firstName: z.string().min(2).max(50).optional(),
  city: z.string().min(2).max(100).optional(),
  country: z.string().min(2).max(100).optional(),
  profession: z.string().max(100).optional().nullable(),
  educationLevel: z.string().max(100).optional().nullable(),
  religiousPractice: z.string().max(500).optional().nullable(),
  maritalStatus: z.string().max(50).optional().nullable(),
  hasChildren: z.boolean().optional(),
  wantsChildren: z.string().max(50).optional().nullable(),
  bio: z.string().max(2000).optional().nullable(),
  lookingFor: z.string().max(2000).optional().nullable(),
  photoUrl: z.string().url().optional().nullable(),
});

export type ProfileUpdateInput = z.infer<typeof profileUpdateSchema>;

export const messageSchema = z.object({
  content: z
    .string()
    .trim()
    .min(1, "Le message ne peut pas être vide.")
    .max(4000, "Message trop long (4000 caractères max)."),
});

export const reportSchema = z.object({
  reportedUserId: z.string().uuid(),
  reason: z.string().min(3, "Veuillez préciser un motif.").max(200),
  description: z.string().max(2000).optional(),
});

export const contactSchema = z.object({
  name: z.string().min(2, "Nom requis.").max(100),
  email: z.string().email("Adresse email invalide."),
  subject: z.string().min(3, "Sujet requis.").max(200),
  message: z.string().min(10, "Message trop court.").max(3000),
});

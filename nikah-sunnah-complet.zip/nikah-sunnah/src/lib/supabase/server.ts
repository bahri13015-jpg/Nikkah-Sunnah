import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { cookies } from "next/headers";
import type { Database } from "@/types/database.types";

/**
 * Client Supabase à utiliser côté serveur : Server Components, Route Handlers
 * (src/app/api/.../route.ts) et Server Actions.
 *
 * Doit être appelé à chaque requête (ne pas mettre en cache au niveau module),
 * car il lit les cookies de la requête en cours.
 */
export function createClient() {
  const cookieStore = cookies();

  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value, ...options });
          } catch {
            // Appelé depuis un Server Component : ignoré, le middleware
            // se charge déjà de rafraîchir la session sur chaque requête.
          }
        },
        remove(name: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value: "", ...options });
          } catch {
            // idem
          }
        },
      },
    }
  );
}

/**
 * Client "admin" avec la clé service_role : bypass RLS.
 * À utiliser UNIQUEMENT côté serveur, pour des opérations d'administration
 * (validation de profils, bannissement, webhooks Stripe). Ne jamais exposer
 * SUPABASE_SERVICE_ROLE_KEY au client.
 */
export function createAdminClient() {
  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    {
      cookies: {
        get() {
          return undefined;
        },
        set() {},
        remove() {},
      },
    }
  );
}

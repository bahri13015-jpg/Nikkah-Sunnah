import { type NextRequest, NextResponse } from "next/server";
import { updateSession } from "@/lib/supabase/middleware";

const AUTH_PAGES = ["/connexion", "/inscription", "/mot-de-passe-oublie", "/reinitialiser-mot-de-passe"];
const PUBLIC_PAGES = [
  "/",
  "/contact",
  "/mentions-legales",
  "/politique-confidentialite",
  "/cgu",
  "/sitemap.xml",
  "/robots.txt",
];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Les routes API gèrent elles-mêmes leur authentification (voir chaque
  // route.ts : supabase.auth.getUser()). Le middleware ne doit pas les
  // bloquer ici, sinon l'inscription, le webhook Stripe et le formulaire
  // de contact (tous appelés sans session) seraient cassés.
  if (pathname.startsWith("/api/")) {
    const { response } = await updateSession(request);
    return response;
  }

  const { response, user } = await updateSession(request);

  const isAuthPage = AUTH_PAGES.some((p) => pathname.startsWith(p));
  const isAdminPage = pathname.startsWith("/admin");
  const isPublicPage =
    PUBLIC_PAGES.includes(pathname) || pathname.startsWith("/verification-email");

  // Non connecté et tente d'accéder à une page protégée → redirection connexion
  if (!user && !isAuthPage && !isPublicPage) {
    const url = request.nextUrl.clone();
    url.pathname = "/connexion";
    url.searchParams.set("redirect", pathname);
    return NextResponse.redirect(url);
  }

  // Déjà connecté et tente d'accéder aux pages d'auth → redirection tableau de bord
  // (on laisse passer /reinitialiser-mot-de-passe, qui nécessite une session
  // de récupération active)
  if (user && isAuthPage && !pathname.startsWith("/reinitialiser-mot-de-passe")) {
    const url = request.nextUrl.clone();
    url.pathname = "/tableau-de-bord";
    return NextResponse.redirect(url);
  }

  // Routes admin : vérifiées en profondeur dans src/app/admin/layout.tsx
  // (lecture du rôle via la table public.users), le middleware ne fait
  // ici qu'un premier filtre "non connecté".
  if (isAdminPage && !user) {
    const url = request.nextUrl.clone();
    url.pathname = "/connexion";
    return NextResponse.redirect(url);
  }

  return response;
}

export const config = {
  matcher: [
    /*
     * Toutes les routes sauf :
     * - fichiers statiques (_next/static, _next/image, favicon)
     * - assets publics
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};

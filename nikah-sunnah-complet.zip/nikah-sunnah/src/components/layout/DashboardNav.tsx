"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import {
  LayoutDashboard,
  Search,
  MessageCircle,
  Sparkles,
  User,
  LogOut,
  Menu,
  X,
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";

const links = [
  { href: "/tableau-de-bord", label: "Tableau de bord", icon: LayoutDashboard },
  { href: "/recherche", label: "Recherche", icon: Search },
  { href: "/messages", label: "Messages", icon: MessageCircle },
  { href: "/premium", label: "Premium", icon: Sparkles },
];

export function DashboardNav({
  profileId,
  isPremium,
}: {
  profileId: string;
  isPremium: boolean;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  const handleLogout = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/connexion");
    router.refresh();
  };

  return (
    <header className="border-b border-line bg-white">
      <div className="container-app flex h-16 items-center justify-between">
        <Link href="/tableau-de-bord" className="font-display text-lg font-semibold text-primary">
          Nikah Sunnah
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {links.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                pathname.startsWith(href)
                  ? "bg-primary/10 text-primary"
                  : "text-ink/60 hover:bg-canvas2"
              )}
            >
              <Icon size={16} />
              {label}
              {href === "/premium" && isPremium && (
                <span className="ml-1 rounded-full bg-accent px-1.5 py-0.5 text-[10px] text-ink">
                  ✓
                </span>
              )}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <Link
            href={`/profil/${profileId}`}
            className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-ink/60 hover:bg-canvas2"
          >
            <User size={16} />
            Mon profil
          </Link>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-ink/60 hover:bg-canvas2"
          >
            <LogOut size={16} />
            Déconnexion
          </button>
        </div>

        <button className="md:hidden" onClick={() => setOpen((o) => !o)} aria-label="Menu">
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <nav className="container-app flex flex-col gap-1 border-t border-line py-3 md:hidden">
          {links.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              onClick={() => setOpen(false)}
              className={cn(
                "flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium",
                pathname.startsWith(href) ? "bg-primary/10 text-primary" : "text-ink/70"
              )}
            >
              <Icon size={18} />
              {label}
            </Link>
          ))}
          <Link
            href={`/profil/${profileId}`}
            onClick={() => setOpen(false)}
            className="flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium text-ink/70"
          >
            <User size={18} />
            Mon profil
          </Link>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 rounded-lg px-3 py-2.5 text-left text-sm font-medium text-danger"
          >
            <LogOut size={18} />
            Déconnexion
          </button>
        </nav>
      )}
    </header>
  );
}

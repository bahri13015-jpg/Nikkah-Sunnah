"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { registerSchema, type RegisterInput } from "@/lib/validations";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/Label";
import { Button } from "@/components/ui/Button";

export function RegisterForm({ gender }: { gender: "homme" | "femme" }) {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
    defaultValues: { gender, country: "France" },
  });

  const onSubmit = async (data: RegisterInput) => {
    setServerError(null);
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const json = await res.json();

    if (!res.ok) {
      setServerError(json.error ?? "Une erreur est survenue.");
      return;
    }

    router.push("/verification-email");
  };

  return (
    <Card>
      <h1 className="font-display text-2xl font-semibold text-ink">
        Inscription —{" "}
        <span className="text-primary">{gender === "homme" ? "Homme" : "Femme"}</span>
      </h1>

      <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4">
        <input type="hidden" value={gender} {...register("gender")} />

        <div>
          <Label htmlFor="firstName">Prénom</Label>
          <Input id="firstName" {...register("firstName")} error={errors.firstName?.message} />
        </div>

        <div>
          <Label htmlFor="birthDate">Date de naissance</Label>
          <Input
            id="birthDate"
            type="date"
            {...register("birthDate")}
            error={errors.birthDate?.message}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="city">Ville</Label>
            <Input id="city" {...register("city")} error={errors.city?.message} />
          </div>
          <div>
            <Label htmlFor="country">Pays</Label>
            <Input id="country" {...register("country")} error={errors.country?.message} />
          </div>
        </div>

        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" {...register("email")} error={errors.email?.message} />
        </div>

        <div>
          <Label htmlFor="password">Mot de passe</Label>
          <Input
            id="password"
            type="password"
            {...register("password")}
            error={errors.password?.message}
          />
        </div>

        <div>
          <Label htmlFor="confirmPassword">Confirmer le mot de passe</Label>
          <Input
            id="confirmPassword"
            type="password"
            {...register("confirmPassword")}
            error={errors.confirmPassword?.message}
          />
        </div>

        <label className="flex items-start gap-2 text-sm text-ink/70">
          <input type="checkbox" className="mt-0.5" {...register("acceptTerms")} />
          <span>
            J'accepte les{" "}
            <Link href="/cgu" className="text-primary underline">
              conditions générales d'utilisation
            </Link>
          </span>
        </label>
        {errors.acceptTerms && (
          <p className="text-sm text-danger">{errors.acceptTerms.message}</p>
        )}

        {serverError && (
          <p className="rounded-lg bg-danger/10 px-3 py-2 text-sm text-danger">
            {serverError}
          </p>
        )}

        <Button type="submit" className="w-full" isLoading={isSubmitting}>
          Créer mon compte
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-ink/60">
        Déjà inscrit(e) ?{" "}
        <Link href="/connexion" className="font-medium text-primary">
          Se connecter
        </Link>
      </p>
    </Card>
  );
}

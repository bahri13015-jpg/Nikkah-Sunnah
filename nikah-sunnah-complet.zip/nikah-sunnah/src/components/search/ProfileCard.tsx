import Link from "next/link";
import { MapPin, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import { calculateAge } from "@/lib/utils";

export interface ProfileCardData {
  id: string;
  first_name: string;
  birth_date: string;
  city: string | null;
  country: string | null;
  profession: string | null;
  photo_url: string | null;
  is_boosted: boolean;
}

export function ProfileCard({ profile }: { profile: ProfileCardData }) {
  return (
    <Link
      href={`/profil/${profile.id}`}
      className="group block overflow-hidden rounded-2xl border border-line bg-white transition-shadow hover:shadow-md"
    >
      <div className="relative aspect-[4/3] bg-canvas2">
        {profile.photo_url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={profile.photo_url}
            alt={profile.first_name}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center font-display text-3xl text-primary/30">
            {profile.first_name.charAt(0)}
          </div>
        )}
        {profile.is_boosted && (
          <Badge tone="primary" className="absolute left-2 top-2 gap-1">
            <Sparkles size={12} /> Mis en avant
          </Badge>
        )}
      </div>
      <div className="p-4">
        <p className="font-display text-base font-semibold text-ink">
          {profile.first_name}, {calculateAge(profile.birth_date)} ans
        </p>
        {(profile.city || profile.country) && (
          <p className="mt-1 flex items-center gap-1 text-xs text-ink/60">
            <MapPin size={12} />
            {[profile.city, profile.country].filter(Boolean).join(", ")}
          </p>
        )}
        {profile.profession && (
          <p className="mt-1 truncate text-xs text-ink/50">{profile.profession}</p>
        )}
      </div>
    </Link>
  );
}

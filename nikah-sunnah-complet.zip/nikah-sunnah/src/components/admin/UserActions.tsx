"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";

export function UserActions({
  userId,
  status,
}: {
  userId: string;
  status: string;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState<string | null>(null);

  const act = async (action: string) => {
    if (action === "ban" && !confirm("Bannir définitivement cet utilisateur ?")) return;
    setLoading(action);
    const res = await fetch("/api/admin/ban", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, action }),
    });
    setLoading(null);
    if (res.ok) router.refresh();
  };

  return (
    <div className="flex gap-2">
      {status !== "banned" && (
        <Button size="sm" variant="danger" onClick={() => act("ban")} isLoading={loading === "ban"}>
          Bannir
        </Button>
      )}
      {status === "active" && (
        <Button size="sm" variant="outline" onClick={() => act("suspend")} isLoading={loading === "suspend"}>
          Suspendre
        </Button>
      )}
      {(status === "suspended" || status === "banned") && (
        <Button size="sm" variant="outline" onClick={() => act("activate")} isLoading={loading === "activate"}>
          Réactiver
        </Button>
      )}
    </div>
  );
}

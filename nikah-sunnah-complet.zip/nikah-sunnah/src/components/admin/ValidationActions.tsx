"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";

export function ValidationActions({ profileId }: { profileId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState<"approve" | "reject" | null>(null);
  const [showReject, setShowReject] = useState(false);
  const [reason, setReason] = useState("");

  const act = async (action: "approve" | "reject") => {
    setLoading(action);
    const res = await fetch("/api/admin/validate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ profileId, action, reason }),
    });
    setLoading(null);
    if (res.ok) {
      router.refresh();
    }
  };

  if (showReject) {
    return (
      <div className="flex flex-1 items-center gap-2">
        <Input
          placeholder="Motif du refus"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          className="h-9"
        />
        <Button
          size="sm"
          variant="danger"
          onClick={() => act("reject")}
          isLoading={loading === "reject"}
        >
          Confirmer
        </Button>
      </div>
    );
  }

  return (
    <div className="flex gap-2">
      <Button size="sm" onClick={() => act("approve")} isLoading={loading === "approve"}>
        <Check size={14} /> Valider
      </Button>
      <Button size="sm" variant="danger" onClick={() => setShowReject(true)}>
        <X size={14} /> Refuser
      </Button>
    </div>
  );
}

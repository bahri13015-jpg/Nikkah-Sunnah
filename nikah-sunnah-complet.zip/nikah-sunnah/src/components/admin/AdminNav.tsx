"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, Users, ShieldCheck, Flag, CreditCard, LogOut } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";

const links = [
  { href: "/admin", label: "Vue d'ensemble", icon: LayoutDashboard, exact: true },
  { href: "/admin/validation", label: "Validation profils", icon: ShieldCheck },
  { href: "/admin/utilisateurs", label: "Utilisateurs", icon: Users },
  { href: "/admin/signalements", label: "Signalements", icon: Flag },
  { href: "/admin/abonnements", label: "Abonnements", icon: CreditCard },
];

export function AdminNav() {
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/connexion");
    router.refresh();
  };

  return (
    <aside className="w-full shrink-0 border-b border-line bg-ink text-canvas md:min-h-screen md:w-60 md:border-b-0 md:border-r">
      <div className="container-app flex h-16 items-center md:h-auto md:px-5 md:py-6">
        <Link href="/admin" className="font-display text-lg font-semibold">
          Nikah Sunnah <span className="text-accent">Admin</span>
        </Link>
      </div>
      <nav className="container-app flex gap-1 overflow-x-auto pb-3 md:flex-col md:px-3 md:pb-6">
        {links.map(({ href, label, icon: Icon, exact }) => {
          const active = exact ? pathname === href : pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium whitespace-nowrap",
                active ? "bg-accent text-ink" : "text-canvas/70 hover:bg-white/10"
              )}
            >
              <Icon size={16} />
              {label}
            </Link>
          );
        })}
        <button
          onClick={handleLogout}
          className="flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-canvas/70 hover:bg-white/10"
        >
          <LogOut size={16} />
          Déconnexion
        </button>
      </nav>
    </aside>
  );
}

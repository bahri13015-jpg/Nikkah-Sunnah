"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";

export function ReportActions({ reportId }: { reportId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState<string | null>(null);

  const act = async (action: "dismiss" | "actioned") => {
    setLoading(action);
    const res = await fetch("/api/admin/reports", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reportId, action }),
    });
    setLoading(null);
    if (res.ok) router.refresh();
  };

  return (
    <div className="flex gap-2">
      <Button size="sm" variant="outline" onClick={() => act("dismiss")} isLoading={loading === "dismiss"}>
        Classer sans suite
      </Button>
      <Button size="sm" variant="danger" onClick={() => act("actioned")} isLoading={loading === "actioned"}>
        Traité (sanction)
      </Button>
    </div>
  );
}

"use client";

import { cn, formatDateFr } from "@/lib/utils";

export interface ConversationWithCounterpart {
  id: string;
  status: "active" | "closed";
  last_message_at: string | null;
  created_at: string;
  closed_at: string | null;
  user1_id: string;
  user2_id: string;
  counterpart: { id: string; user_id: string; first_name: string; photo_url: string | null } | null;
}

export function ConversationList({
  conversations,
  selectedId,
  onSelect,
}: {
  conversations: ConversationWithCounterpart[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}) {
  return (
    <div className="border-r border-line">
      <ul className="divide-y divide-line">
        {conversations.map((c) => (
          <li key={c.id}>
            <button
              onClick={() => onSelect(c.id)}
              className={cn(
                "flex w-full items-center gap-3 px-4 py-3 text-left transition-colors",
                selectedId === c.id ? "bg-primary/5" : "hover:bg-canvas2"
              )}
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full bg-canvas2 font-display text-primary">
                {c.counterpart?.photo_url ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={c.counterpart.photo_url}
                    alt=""
                    className="h-full w-full object-cover"
                  />
                ) : (
                  c.counterpart?.first_name?.charAt(0) ?? "?"
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-ink">
                  {c.counterpart?.first_name ?? "Utilisateur"}
                </p>
                <p className="truncate text-xs text-ink/50">
                  {c.status === "active"
                    ? "Conversation active"
                    : `Clôturée le ${c.closed_at ? formatDateFr(c.closed_at) : ""}`}
                </p>
              </div>
              {c.status === "active" && (
                <span className="h-2 w-2 shrink-0 rounded-full bg-success" />
              )}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

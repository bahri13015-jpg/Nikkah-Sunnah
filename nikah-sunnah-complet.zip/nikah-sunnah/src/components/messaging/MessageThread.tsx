"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Send, Lock } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";
import type { Database } from "@/types/database.types";

type Message = Database["public"]["Tables"]["messages"]["Row"];

export function MessageThread({
  conversationId,
  currentUserId,
  counterpartName,
  status,
  initialMessages,
  onBack,
}: {
  conversationId: string;
  currentUserId: string;
  counterpartName: string;
  status: "active" | "closed";
  initialMessages: Message[];
  onBack: () => void;
}) {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [content, setContent] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [closing, setClosing] = useState(false);
  const [currentStatus, setCurrentStatus] = useState(status);
  const bottomRef = useRef<HTMLDivElement>(null);

  // Charge les messages (utile pour l'historique clôturé, et garantit la
  // fraîcheur des données pour la conversation active).
  useEffect(() => {
    fetch(`/api/conversations/${conversationId}/messages`)
      .then((r) => r.json())
      .then((json) => {
        if (json.messages) setMessages(json.messages);
      });
  }, [conversationId]);

  // Abonnement temps réel — uniquement utile pour une conversation active.
  useEffect(() => {
    if (currentStatus !== "active") return;
    const supabase = createClient();
    const channel = supabase
      .channel(`messages:${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${conversationId}`,
        },
        (payload) => {
          setMessages((prev) => {
            if (prev.some((m) => m.id === (payload.new as Message).id)) return prev;
            return [...prev, payload.new as Message];
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [conversationId, currentStatus]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const sendMessage = async () => {
    if (!content.trim()) return;
    setSending(true);
    setError(null);

    const res = await fetch(`/api/conversations/${conversationId}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });
    const json = await res.json();

    if (!res.ok) {
      setError(json.error ?? "Impossible d'envoyer le message.");
      setSending(false);
      return;
    }

    setMessages((prev) => [...prev, json.message]);
    setContent("");
    setSending(false);
  };

  const closeConversation = async () => {
    if (!confirm("Clôturer cette conversation ? Cette action est définitive.")) return;
    setClosing(true);
    const res = await fetch(`/api/conversations/${conversationId}`, {
      method: "PATCH",
    });
    if (res.ok) {
      setCurrentStatus("closed");
    }
    setClosing(false);
  };

  return (
    <div className="flex h-[60vh] flex-col">
      <div className="flex items-center justify-between border-b border-line px-4 py-3">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="md:hidden" aria-label="Retour">
            <ArrowLeft size={18} />
          </button>
          <p className="font-medium text-ink">{counterpartName}</p>
        </div>
        {currentStatus === "active" ? (
          <Button variant="ghost" size="sm" onClick={closeConversation} isLoading={closing}>
            Clôturer
          </Button>
        ) : (
          <span className="flex items-center gap-1 text-xs text-ink/40">
            <Lock size={12} /> Clôturée
          </span>
        )}
      </div>

      <div className="flex-1 space-y-2 overflow-y-auto px-4 py-4">
        {messages.map((m) => (
          <div
            key={m.id}
            className={cn(
              "max-w-[75%] rounded-2xl px-3.5 py-2 text-sm",
              m.sender_id === currentUserId
                ? "ml-auto bg-primary text-canvas"
                : "bg-canvas2 text-ink"
            )}
          >
            {m.content}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {currentStatus === "active" ? (
        <div className="border-t border-line p-3">
          {error && <p className="mb-2 text-sm text-danger">{error}</p>}
          <div className="flex gap-2">
            <input
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              placeholder="Écrire un message respectueux..."
              className="h-11 flex-1 rounded-xl border border-line bg-white px-3.5 text-sm focus:border-primary"
            />
            <Button onClick={sendMessage} isLoading={sending} aria-label="Envoyer">
              <Send size={16} />
            </Button>
          </div>
        </div>
      ) : (
        <div className="border-t border-line p-3 text-center text-xs text-ink/40">
          Cette conversation est clôturée.
        </div>
      )}
    </div>
  );
}

"use client";

import { useState } from "react";
import { ConversationList, type ConversationWithCounterpart } from "./ConversationList";
import { MessageThread } from "./MessageThread";
import type { Database } from "@/types/database.types";

type Message = Database["public"]["Tables"]["messages"]["Row"];

export function MessagingApp({
  currentUserId,
  conversations,
  initialActiveId,
  initialMessages,
}: {
  currentUserId: string;
  conversations: ConversationWithCounterpart[];
  initialActiveId: string | null;
  initialMessages: Message[];
}) {
  const [selectedId, setSelectedId] = useState<string | null>(
    initialActiveId ?? conversations[0]?.id ?? null
  );
  const [showThreadOnMobile, setShowThreadOnMobile] = useState(false);

  const selected = conversations.find((c) => c.id === selectedId) ?? null;

  if (conversations.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-line bg-white p-10 text-center text-sm text-ink/50">
        Aucune conversation pour le moment. Rendez-vous dans{" "}
        <span className="font-medium text-primary">Recherche</span> pour
        envoyer votre premier message.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 overflow-hidden rounded-2xl border border-line bg-white md:grid-cols-[280px_1fr] md:gap-0">
      <div className={showThreadOnMobile ? "hidden md:block" : "block"}>
        <ConversationList
          conversations={conversations}
          selectedId={selectedId}
          onSelect={(id) => {
            setSelectedId(id);
            setShowThreadOnMobile(true);
          }}
        />
      </div>

      <div className={showThreadOnMobile ? "block" : "hidden md:block"}>
        {selected ? (
          <MessageThread
            key={selected.id}
            conversationId={selected.id}
            currentUserId={currentUserId}
            counterpartName={selected.counterpart?.first_name ?? "Utilisateur"}
            status={selected.status}
            initialMessages={selected.id === initialActiveId ? initialMessages : []}
            onBack={() => setShowThreadOnMobile(false)}
          />
        ) : (
          <div className="flex h-full items-center justify-center p-10 text-sm text-ink/40">
            Sélectionnez une conversation
          </div>
        )}
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { profileUpdateSchema, type ProfileUpdateInput } from "@/lib/validations";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/Label";
import { Textarea } from "@/components/ui/Textarea";
import { Button } from "@/components/ui/Button";
import type { Database } from "@/types/database.types";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export function ProfileEditForm({ profile }: { profile: Profile }) {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ProfileUpdateInput>({
    resolver: zodResolver(profileUpdateSchema),
    defaultValues: {
      firstName: profile.first_name,
      city: profile.city ?? "",
      country: profile.country ?? "",
      profession: profile.profession ?? "",
      educationLevel: profile.education_level ?? "",
      religiousPractice: profile.religious_practice ?? "",
      maritalStatus: profile.marital_status ?? "",
      hasChildren: profile.has_children,
      wantsChildren: profile.wants_children ?? "",
      bio: profile.bio ?? "",
      lookingFor: profile.looking_for ?? "",
    },
  });

  const onSubmit = async (data: ProfileUpdateInput) => {
    setServerError(null);
    setSuccess(false);

    const res = await fetch(`/api/profiles/${profile.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      const json = await res.json();
      setServerError(json.error ?? "Une erreur est survenue.");
      return;
    }

    setSuccess(true);
    router.refresh();
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <p className="text-xs text-ink/50">
        Toute modification repasse votre profil en attente de validation par
        notre équipe avant d'être de nouveau visible.
      </p>

      <div>
        <Label htmlFor="firstName">Prénom</Label>
        <Input id="firstName" {...register("firstName")} error={errors.firstName?.message} />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label htmlFor="city">Ville</Label>
          <Input id="city" {...register("city")} error={errors.city?.message} />
        </div>
        <div>
          <Label htmlFor="country">Pays</Label>
          <Input id="country" {...register("country")} error={errors.country?.message} />
        </div>
      </div>

      <div>
        <Label htmlFor="profession">Profession</Label>
        <Input id="profession" {...register("profession")} />
      </div>

      <div>
        <Label htmlFor="educationLevel">Niveau d'études</Label>
        <Input id="educationLevel" {...register("educationLevel")} />
      </div>

      <div>
        <Label htmlFor="religiousPractice">Pratique religieuse</Label>
        <Textarea
          id="religiousPractice"
          rows={2}
          placeholder="Décrivez votre pratique (prière, niqab/barbe, école, etc.)"
          {...register("religiousPractice")}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label htmlFor="maritalStatus">Statut marital</Label>
          <Input
            id="maritalStatus"
            placeholder="Célibataire, divorcé(e)..."
            {...register("maritalStatus")}
          />
        </div>
        <div>
          <Label htmlFor="wantsChildren">Enfants souhaités</Label>
          <Input id="wantsChildren" {...register("wantsChildren")} />
        </div>
      </div>

      <label className="flex items-center gap-2 text-sm text-ink/70">
        <input type="checkbox" {...register("hasChildren")} />
        J'ai déjà des enfants
      </label>

      <div>
        <Label htmlFor="bio">À propos de moi</Label>
        <Textarea id="bio" rows={4} {...register("bio")} error={errors.bio?.message} />
      </div>

      <div>
        <Label htmlFor="lookingFor">Profil recherché</Label>
        <Textarea
          id="lookingFor"
          rows={4}
          {...register("lookingFor")}
          error={errors.lookingFor?.message}
        />
      </div>

      {serverError && (
        <p className="rounded-lg bg-danger/10 px-3 py-2 text-sm text-danger">{serverError}</p>
      )}
      {success && (
        <p className="rounded-lg bg-success/10 px-3 py-2 text-sm text-success">
          Profil mis à jour ✓
        </p>
      )}

      <Button type="submit" isLoading={isSubmitting}>
        Enregistrer
      </Button>
    </form>
  );
}

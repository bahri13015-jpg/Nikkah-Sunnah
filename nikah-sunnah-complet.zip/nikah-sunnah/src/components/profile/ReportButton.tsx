"use client";

import { useState } from "react";
import { Flag } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Textarea } from "@/components/ui/Textarea";
import { Label } from "@/components/ui/Label";

const REASONS = [
  "Faux profil",
  "Comportement inapproprié",
  "Harcèlement",
  "Arnaque",
  "Autre",
];

export function ReportButton({ reportedUserId }: { reportedUserId: string }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState(REASONS[0]);
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">(
    "idle"
  );

  const submit = async () => {
    setStatus("sending");
    const res = await fetch("/api/reports", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reportedUserId, reason, description }),
    });
    setStatus(res.ok ? "sent" : "error");
  };

  if (!open) {
    return (
      <Button variant="ghost" onClick={() => setOpen(true)}>
        <Flag size={16} />
        Signaler
      </Button>
    );
  }

  if (status === "sent") {
    return (
      <p className="rounded-lg bg-success/10 px-3 py-2 text-sm text-success">
        Signalement envoyé. Notre équipe va l'examiner.
      </p>
    );
  }

  return (
    <div className="w-full rounded-xl border border-line bg-canvas2 p-4">
      <p className="text-sm font-semibold text-ink">Signaler ce profil</p>

      <div className="mt-3">
        <Label htmlFor="reason">Motif</Label>
        <select
          id="reason"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          className="h-11 w-full rounded-xl border border-line bg-white px-3.5 text-sm"
        >
          {REASONS.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </select>
      </div>

      <div className="mt-3">
        <Label htmlFor="description">Détails (optionnel)</Label>
        <Textarea
          id="description"
          rows={3}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </div>

      {status === "error" && (
        <p className="mt-2 text-sm text-danger">Une erreur est survenue.</p>
      )}

      <div className="mt-3 flex gap-2">
        <Button variant="danger" size="sm" onClick={submit} isLoading={status === "sending"}>
          Envoyer le signalement
        </Button>
        <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>
          Annuler
        </Button>
      </div>
    </div>
  );
}

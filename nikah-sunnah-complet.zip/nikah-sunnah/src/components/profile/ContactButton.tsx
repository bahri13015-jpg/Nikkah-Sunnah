"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/Button";

export function ContactButton({
  recipientId,
  existingConversationId,
  existingStatus,
}: {
  recipientId: string;
  existingConversationId?: string;
  existingStatus?: string;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (existingConversationId) {
    return (
      <Button
        variant={existingStatus === "closed" ? "outline" : "primary"}
        onClick={() => router.push("/messages")}
      >
        <MessageCircle size={16} />
        {existingStatus === "closed" ? "Conversation clôturée" : "Voir la conversation"}
      </Button>
    );
  }

  const start = async () => {
    setLoading(true);
    setError(null);
    const res = await fetch("/api/conversations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ recipientId }),
    });
    const json = await res.json();

    if (!res.ok) {
      setError(json.error ?? "Impossible de démarrer la conversation.");
      setLoading(false);
      return;
    }

    router.push("/messages");
  };

  return (
    <div>
      <Button onClick={start} isLoading={loading}>
        <MessageCircle size={16} />
        Envoyer un message
      </Button>
      {error && <p className="mt-2 text-sm text-danger">{error}</p>}
    </div>
  );
}

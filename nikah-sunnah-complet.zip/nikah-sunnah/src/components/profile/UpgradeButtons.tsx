"use client";

import { useState } from "react";
import { Button } from "@/components/ui/Button";

export function UpgradeButtons({ isPremium }: { isPremium: boolean }) {
  const [loading, setLoading] = useState<"premium" | "boost" | null>(null);

  const go = async (type: "premium" | "boost") => {
    setLoading(type);
    const res = await fetch(
      type === "premium" ? "/api/stripe/checkout" : "/api/stripe/boost",
      { method: "POST" }
    );
    const json = await res.json();
    if (json.url) {
      window.location.href = json.url;
    } else {
      setLoading(null);
    }
  };

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <div className="rounded-2xl border-2 border-primary bg-white p-6">
        <p className="font-display text-lg font-semibold text-primary">Premium</p>
        <p className="mt-1 text-3xl font-semibold text-ink">
          12,99 € <span className="text-sm font-normal text-ink/50">/mois</span>
        </p>
        <ul className="mt-4 space-y-2 text-sm text-ink/70">
          <li>✓ Messages illimités</li>
          <li>✓ Badge profil vérifié</li>
          <li>✓ Filtres de recherche avancés</li>
          <li>✓ Visibilité améliorée</li>
        </ul>
        <Button
          className="mt-5 w-full"
          onClick={() => go("premium")}
          isLoading={loading === "premium"}
          disabled={isPremium}
        >
          {isPremium ? "Déjà abonné ✓" : "Passer Premium"}
        </Button>
      </div>

      <div className="rounded-2xl border border-line bg-white p-6">
        <p className="font-display text-lg font-semibold text-accent">Boost profil</p>
        <p className="mt-1 text-3xl font-semibold text-ink">
          4,99 € <span className="text-sm font-normal text-ink/50">/ 7 jours</span>
        </p>
        <ul className="mt-4 space-y-2 text-sm text-ink/70">
          <li>✓ Mise en avant de votre profil</li>
          <li>✓ Apparition en tête des résultats</li>
          <li>✓ Badge "Mis en avant"</li>
        </ul>
        <Button
          variant="secondary"
          className="mt-5 w-full"
          onClick={() => go("boost")}
          isLoading={loading === "boost"}
        >
          Booster mon profil
        </Button>
      </div>
    </div>
  );
}

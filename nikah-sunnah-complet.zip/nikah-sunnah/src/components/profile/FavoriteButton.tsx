"use client";

import { useState } from "react";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/Button";

export function FavoriteButton({
  favoritedUserId,
  initialIsFavorite,
}: {
  favoritedUserId: string;
  initialIsFavorite: boolean;
}) {
  const [isFavorite, setIsFavorite] = useState(initialIsFavorite);
  const [loading, setLoading] = useState(false);

  const toggle = async () => {
    setLoading(true);
    const res = await fetch("/api/favorites", {
      method: isFavorite ? "DELETE" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ favoritedUserId }),
    });
    if (res.ok) setIsFavorite((v) => !v);
    setLoading(false);
  };

  return (
    <Button variant="outline" onClick={toggle} isLoading={loading}>
      <Heart size={16} className={isFavorite ? "fill-clay text-clay" : ""} />
      {isFavorite ? "Dans mes favoris" : "Ajouter aux favoris"}
    </Button>
  );
}

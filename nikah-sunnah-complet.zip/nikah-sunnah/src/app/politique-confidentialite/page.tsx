export const metadata = { title: "Politique de confidentialité" };

export default function PolitiqueConfidentialitePage() {
  return (
    <div className="container-app max-w-3xl py-16">
      <h1 className="font-display text-3xl font-semibold text-ink">
        Politique de confidentialité
      </h1>
      <p className="mt-2 text-sm italic text-ink/50">
        Modèle à adapter et à faire valider par un professionnel du droit.
        Ce site traite des données sensibles au sens du RGPD (convictions
        religieuses) : un avis juridique est fortement recommandé avant mise
        en production.
      </p>

      <div className="prose prose-sm mt-8 max-w-none text-ink/80">
        <h2>Données collectées</h2>
        <p>
          Identité (prénom, date de naissance), coordonnées (email, ville,
          pays), informations de profil matrimonial (situation, pratique
          religieuse, description, photos), messages échangés, données de
          paiement (traitées exclusivement par Stripe, jamais stockées par
          nos soins).
        </p>

        <h2>Finalités</h2>
        <p>
          Mise en relation matrimoniale, modération des profils, prévention
          de la fraude et des abus, gestion des abonnements.
        </p>

        <h2>Base légale</h2>
        <p>
          Les données relatives à la pratique religieuse sont des données
          sensibles (art. 9 RGPD) traitées sur la base de votre consentement
          explicite, recueilli lors de l'inscription.
        </p>

        <h2>Durée de conservation</h2>
        <p>
          Les données sont conservées tant que le compte est actif, puis
          supprimées dans un délai de [durée] après suppression du compte.
        </p>

        <h2>Vos droits</h2>
        <p>
          Conformément au RGPD, vous disposez d'un droit d'accès, de
          rectification, d'effacement et de portabilité de vos données.
          Contactez-nous via le <a href="/contact">formulaire de contact</a>.
        </p>

        <h2>Sous-traitants</h2>
        <p>
          Supabase (hébergement base de données et authentification), Stripe
          (paiements), Vercel (hébergement applicatif).
        </p>
      </div>
    </div>
  );
}

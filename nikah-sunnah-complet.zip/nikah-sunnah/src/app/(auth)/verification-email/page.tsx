"use client";

import { useState } from "react";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { createClient } from "@/lib/supabase/client";

export default function VerificationEmailPage() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">(
    "idle"
  );

  const resend = async () => {
    if (!email) return;
    setStatus("sending");
    const supabase = createClient();
    const { error } = await supabase.auth.resend({ type: "signup", email });
    setStatus(error ? "error" : "sent");
  };

  return (
    <Card className="text-center">
      <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-2xl">
        ✉️
      </div>
      <h1 className="font-display text-2xl font-semibold text-ink">
        Vérifiez votre email
      </h1>
      <p className="mt-2 text-sm text-ink/60">
        Nous vous avons envoyé un lien de confirmation. Cliquez dessus pour
        activer votre compte avant de vous connecter.
      </p>

      <div className="mt-6 space-y-3 text-left">
        <p className="text-xs font-medium text-ink/60">
          Vous n'avez rien reçu ? Renvoyez l'email :
        </p>
        <Input
          type="email"
          placeholder="votre@email.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <Button
          variant="outline"
          className="w-full"
          onClick={resend}
          isLoading={status === "sending"}
        >
          Renvoyer l'email de confirmation
        </Button>
        {status === "sent" && (
          <p className="text-sm text-success">Email renvoyé ✓</p>
        )}
        {status === "error" && (
          <p className="text-sm text-danger">
            Impossible de renvoyer l'email pour le moment.
          </p>
        )}
      </div>
    </Card>
  );
}

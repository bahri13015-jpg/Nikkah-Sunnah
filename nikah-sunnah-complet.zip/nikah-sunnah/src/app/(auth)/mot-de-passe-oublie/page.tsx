"use client";

import { useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { forgotPasswordSchema } from "@/lib/validations";
import { createClient } from "@/lib/supabase/client";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/Label";
import { Button } from "@/components/ui/Button";

export default function MotDePasseOubliePage() {
  const [sent, setSent] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<{ email: string }>({ resolver: zodResolver(forgotPasswordSchema) });

  const onSubmit = async ({ email }: { email: string }) => {
    setServerError(null);
    const supabase = createClient();
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? window.location.origin;

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${siteUrl}/api/auth/confirm?next=/reinitialiser-mot-de-passe`,
    });

    if (error) {
      setServerError("Une erreur est survenue. Réessayez.");
      return;
    }
    setSent(true);
  };

  if (sent) {
    return (
      <Card className="text-center">
        <h1 className="font-display text-xl font-semibold text-ink">
          Email envoyé ✓
        </h1>
        <p className="mt-2 text-sm text-ink/60">
          Si un compte existe avec cette adresse, un lien de réinitialisation
          vient de lui être envoyé.
        </p>
      </Card>
    );
  }

  return (
    <Card>
      <h1 className="font-display text-2xl font-semibold text-ink">
        Mot de passe oublié
      </h1>
      <p className="mt-2 text-sm text-ink/60">
        Indiquez votre email, nous vous enverrons un lien de réinitialisation.
      </p>

      <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4">
        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" {...register("email")} error={errors.email?.message} />
        </div>

        {serverError && (
          <p className="rounded-lg bg-danger/10 px-3 py-2 text-sm text-danger">
            {serverError}
          </p>
        )}

        <Button type="submit" className="w-full" isLoading={isSubmitting}>
          Envoyer le lien
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-ink/60">
        <Link href="/connexion" className="font-medium text-primary">
          Retour à la connexion
        </Link>
      </p>
    </Card>
  );
}

import Link from "next/link";
import { Card } from "@/components/ui/Card";

export default function InscriptionChoixPage() {
  return (
    <Card>
      <h1 className="font-display text-2xl font-semibold text-ink">
        Créer mon compte
      </h1>
      <p className="mt-2 text-sm text-ink/60">
        L'inscription est séparée pour respecter les usages d'une recherche
        sérieuse en vue du mariage.
      </p>

      <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Link
          href="/inscription/homme"
          className="flex flex-col items-center gap-2 rounded-xl border border-line bg-canvas2 px-4 py-6 text-center transition-colors hover:border-primary"
        >
          <span className="font-display text-lg font-medium text-primary">
            Je suis un homme
          </span>
          <span className="text-xs text-ink/60">à la recherche d'une épouse</span>
        </Link>

        <Link
          href="/inscription/femme"
          className="flex flex-col items-center gap-2 rounded-xl border border-line bg-canvas2 px-4 py-6 text-center transition-colors hover:border-primary"
        >
          <span className="font-display text-lg font-medium text-primary">
            Je suis une femme
          </span>
          <span className="text-xs text-ink/60">à la recherche d'un époux</span>
        </Link>
      </div>

      <p className="mt-6 text-center text-sm text-ink/60">
        Déjà inscrit(e) ?{" "}
        <Link href="/connexion" className="font-medium text-primary">
          Se connecter
        </Link>
      </p>
    </Card>
  );
}

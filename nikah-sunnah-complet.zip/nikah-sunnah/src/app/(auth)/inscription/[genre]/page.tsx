import { notFound } from "next/navigation";
import { RegisterForm } from "@/components/auth/RegisterForm";

const VALID_GENDERS = ["homme", "femme"] as const;
type Genre = (typeof VALID_GENDERS)[number];

export default function InscriptionGenrePage({
  params,
}: {
  params: { genre: string };
}) {
  if (!VALID_GENDERS.includes(params.genre as Genre)) {
    notFound();
  }

  const genre = params.genre as Genre;

  return <RegisterForm gender={genre} />;
}

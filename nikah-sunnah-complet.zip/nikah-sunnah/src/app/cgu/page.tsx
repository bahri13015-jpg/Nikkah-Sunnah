export const metadata = { title: "Conditions générales d'utilisation" };

export default function CguPage() {
  return (
    <div className="container-app max-w-3xl py-16">
      <h1 className="font-display text-3xl font-semibold text-ink">
        Conditions générales d'utilisation
      </h1>
      <p className="mt-2 text-sm italic text-ink/50">
        Modèle à adapter et à faire valider par un professionnel du droit
        avant mise en production.
      </p>

      <div className="prose prose-sm mt-8 max-w-none text-ink/80">
        <h2>1. Objet</h2>
        <p>
          Nikah Sunnah est une plateforme de mise en relation matrimoniale
          réservée aux personnes majeures, sincèrement engagées dans une
          démarche de mariage.
        </p>

        <h2>2. Inscription</h2>
        <p>
          L'inscription est gratuite et réservée aux personnes de 18 ans et
          plus. Chaque profil est soumis à une validation manuelle avant
          publication. La plateforme se réserve le droit de refuser ou
          suspendre tout compte ne respectant pas les présentes conditions.
        </p>

        <h2>3. Règles de messagerie</h2>
        <p>
          Chaque utilisateur ne peut maintenir qu'une seule conversation
          active à la fois. Les comptes gratuits sont limités à 3 messages
          par jour ; l'abonnement Premium permet un nombre illimité de
          messages.
        </p>

        <h2>4. Abonnement Premium et Boost</h2>
        <p>
          L'abonnement Premium (12,99 €/mois) et le Boost de profil
          (4,99 €/7 jours) sont des services payants proposés en option,
          facturés via Stripe. L'abonnement Premium se renouvelle
          automatiquement chaque mois jusqu'à résiliation.
        </p>

        <h2>5. Comportement attendu</h2>
        <p>
          Tout comportement frauduleux, harcelant ou contraire au respect dû
          à autrui peut entraîner la suspension ou la suppression définitive
          du compte, sans préavis ni remboursement.
        </p>

        <h2>6. Signalement</h2>
        <p>
          Chaque profil dispose d'un bouton de signalement. Les
          signalements sont examinés par notre équipe de modération.
        </p>

        <h2>7. Responsabilité</h2>
        <p>
          La plateforme est un outil de mise en relation ; elle ne garantit
          pas l'issue des échanges entre utilisateurs et ne saurait être
          tenue responsable des relations engagées en dehors du site.
        </p>
      </div>
    </div>
  );
}

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { profileUpdateSchema } from "@/lib/validations";

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Non authentifié." }, { status: 401 });
  }

  const body = await request.json();
  const parsed = profileUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.errors[0]?.message ?? "Données invalides." },
      { status: 400 }
    );
  }

  const d = parsed.data;
  const { error } = await supabase
    .from("profiles")
    .update({
      first_name: d.firstName,
      city: d.city,
      country: d.country,
      profession: d.profession,
      education_level: d.educationLevel,
      religious_practice: d.religiousPractice,
      marital_status: d.maritalStatus,
      has_children: d.hasChildren,
      wants_children: d.wantsChildren,
      bio: d.bio,
      looking_for: d.lookingFor,
      photo_url: d.photoUrl,
    })
    .eq("id", params.id)
    .eq("user_id", user.id); // RLS protège déjà, double vérification explicite

  if (error) {
    return NextResponse.json(
      { error: "Impossible de mettre à jour le profil." },
      { status: 400 }
    );
  }

  return NextResponse.json({ success: true });
}

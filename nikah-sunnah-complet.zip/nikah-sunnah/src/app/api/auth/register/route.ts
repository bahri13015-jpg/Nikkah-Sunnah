import { NextRequest, NextResponse } from "next/server";
import { createClient, createAdminClient } from "@/lib/supabase/server";
import { registerSchema } from "@/lib/validations";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const parsed = registerSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.errors[0]?.message ?? "Données invalides." },
      { status: 400 }
    );
  }

  const { gender, firstName, birthDate, city, country, email, password } =
    parsed.data;

  const supabase = createClient();
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

  const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${siteUrl}/api/auth/confirm`,
    },
  });

  if (signUpError) {
    const message = signUpError.message.includes("already registered")
      ? "Un compte existe déjà avec cet email."
      : "Impossible de créer le compte. Réessayez.";
    return NextResponse.json({ error: message }, { status: 400 });
  }

  const userId = signUpData.user?.id;
  if (!userId) {
    return NextResponse.json(
      { error: "Impossible de créer le compte. Réessayez." },
      { status: 500 }
    );
  }

  // Pas encore de session (email non confirmé) : on insère la fiche profil
  // via le client admin, qui contourne la RLS pour cette seule opération
  // contrôlée côté serveur juste après la création du compte.
  const admin = createAdminClient();
  const { error: profileError } = await admin.from("profiles").insert({
    user_id: userId,
    gender,
    first_name: firstName,
    birth_date: birthDate,
    city,
    country,
  });

  if (profileError) {
    return NextResponse.json(
      { error: "Compte créé mais la fiche profil n'a pas pu être enregistrée. Contactez le support." },
      { status: 500 }
    );
  }

  return NextResponse.json({ success: true }, { status: 201 });
}

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { data: isAdmin } = await supabase.rpc("is_admin");
  if (!isAdmin) {
    return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
  }

  const { profileId, action, reason } = await request.json();
  if (!profileId || !["approve", "reject"].includes(action)) {
    return NextResponse.json({ error: "Requête invalide." }, { status: 400 });
  }

  const { error } = await supabase
    .from("profiles")
    .update({
      status: action === "approve" ? "approved" : "rejected",
      rejection_reason: action === "reject" ? reason ?? null : null,
    })
    .eq("id", profileId);

  if (error) {
    return NextResponse.json({ error: "Impossible de mettre à jour le profil." }, { status: 400 });
  }

  await supabase.from("admin_actions").insert({
    admin_id: user.id,
    action_type: action === "approve" ? "profile_approved" : "profile_rejected",
    target_table: "profiles",
    target_id: profileId,
    details: reason ? { reason } : null,
  });

  return NextResponse.json({ success: true });
}

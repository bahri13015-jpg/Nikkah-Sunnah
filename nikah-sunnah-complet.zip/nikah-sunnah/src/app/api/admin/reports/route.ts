import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { data: isAdmin } = await supabase.rpc("is_admin");
  if (!isAdmin) {
    return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
  }

  const { reportId, action } = await request.json();
  if (!reportId || !["dismiss", "actioned"].includes(action)) {
    return NextResponse.json({ error: "Requête invalide." }, { status: 400 });
  }

  const { error } = await supabase
    .from("reports")
    .update({
      status: action === "dismiss" ? "dismissed" : "actioned",
      reviewed_by: user.id,
      reviewed_at: new Date().toISOString(),
    })
    .eq("id", reportId);

  if (error) {
    return NextResponse.json({ error: "Impossible de mettre à jour le signalement." }, { status: 400 });
  }

  await supabase.from("admin_actions").insert({
    admin_id: user.id,
    action_type: `report_${action}`,
    target_table: "reports",
    target_id: reportId,
  });

  return NextResponse.json({ success: true });
}

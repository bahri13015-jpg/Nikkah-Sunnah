import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const ACTION_TO_STATUS: Record<string, string> = {
  ban: "banned",
  suspend: "suspended",
  activate: "active",
};

export async function POST(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { data: isAdmin } = await supabase.rpc("is_admin");
  if (!isAdmin) {
    return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
  }

  const { userId, action } = await request.json();
  const newStatus = ACTION_TO_STATUS[action];
  if (!userId || !newStatus) {
    return NextResponse.json({ error: "Requête invalide." }, { status: 400 });
  }

  if (userId === user.id) {
    return NextResponse.json(
      { error: "Vous ne pouvez pas effectuer cette action sur votre propre compte." },
      { status: 400 }
    );
  }

  const { error } = await supabase
    .from("users")
    .update({ status: newStatus })
    .eq("id", userId);

  if (error) {
    return NextResponse.json({ error: "Impossible de mettre à jour cet utilisateur." }, { status: 400 });
  }

  await supabase.from("admin_actions").insert({
    admin_id: user.id,
    action_type: `user_${action}`,
    target_table: "users",
    target_id: userId,
  });

  return NextResponse.json({ success: true });
}

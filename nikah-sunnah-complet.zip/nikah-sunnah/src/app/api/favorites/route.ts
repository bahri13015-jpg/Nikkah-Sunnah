import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { favoritedUserId } = await request.json();
  if (!favoritedUserId || favoritedUserId === user.id) {
    return NextResponse.json({ error: "Favori invalide." }, { status: 400 });
  }

  const { error } = await supabase
    .from("favorites")
    .insert({ user_id: user.id, favorited_user_id: favoritedUserId });

  if (error) {
    return NextResponse.json({ error: "Impossible d'ajouter ce favori." }, { status: 400 });
  }
  return NextResponse.json({ success: true }, { status: 201 });
}

export async function DELETE(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { favoritedUserId } = await request.json();

  const { error } = await supabase
    .from("favorites")
    .delete()
    .eq("user_id", user.id)
    .eq("favorited_user_id", favoritedUserId);

  if (error) {
    return NextResponse.json({ error: "Impossible de retirer ce favori." }, { status: 400 });
  }
  return NextResponse.json({ success: true });
}

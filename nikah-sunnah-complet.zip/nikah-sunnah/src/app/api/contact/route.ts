import { NextRequest, NextResponse } from "next/server";
import { contactSchema } from "@/lib/validations";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const parsed = contactSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.errors[0]?.message ?? "Données invalides." },
      { status: 400 }
    );
  }

  // TODO production : brancher un service d'envoi d'email (ex. Resend) ici
  // pour transmettre parsed.data au support. Pour l'instant, on journalise
  // côté serveur uniquement.
  console.log("[contact]", parsed.data);

  return NextResponse.json({ success: true });
}

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { reportSchema } from "@/lib/validations";

export async function POST(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Non authentifié." }, { status: 401 });
  }

  const body = await request.json();
  const parsed = reportSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.errors[0]?.message ?? "Données invalides." },
      { status: 400 }
    );
  }

  if (parsed.data.reportedUserId === user.id) {
    return NextResponse.json(
      { error: "Vous ne pouvez pas vous signaler vous-même." },
      { status: 400 }
    );
  }

  const { error } = await supabase.from("reports").insert({
    reporter_id: user.id,
    reported_user_id: parsed.data.reportedUserId,
    reason: parsed.data.reason,
    description: parsed.data.description,
  });

  if (error) {
    return NextResponse.json(
      { error: "Impossible d'envoyer le signalement." },
      { status: 400 }
    );
  }

  return NextResponse.json({ success: true }, { status: 201 });
}

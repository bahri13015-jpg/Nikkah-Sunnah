import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { stripe } from "@/lib/stripe";

export async function POST() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer_email: user.email,
    line_items: [
      {
        price: process.env.STRIPE_PRICE_ID_BOOST!,
        quantity: 1,
      },
    ],
    success_url: `${siteUrl}/premium?boost=1`,
    cancel_url: `${siteUrl}/premium?canceled=1`,
    metadata: { userId: user.id, type: "boost" },
  });

  return NextResponse.json({ url: session.url });
}

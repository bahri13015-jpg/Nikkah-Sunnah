import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { data, error } = await supabase
    .from("conversations")
    .select(
      "id, status, last_message_at, created_at, user1_id, user2_id, closed_at"
    )
    .or(`user1_id.eq.${user.id},user2_id.eq.${user.id}`)
    .order("status", { ascending: true }) // active d'abord
    .order("last_message_at", { ascending: false, nullsFirst: false });

  if (error) {
    return NextResponse.json({ error: "Erreur lors du chargement." }, { status: 400 });
  }

  return NextResponse.json({ conversations: data });
}

export async function POST(request: NextRequest) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { recipientId } = await request.json();
  if (!recipientId || recipientId === user.id) {
    return NextResponse.json({ error: "Destinataire invalide." }, { status: 400 });
  }

  // Convention : on stocke toujours les participants par ordre lexicographique
  // pour garantir l'unicité de la paire (cf. index unique en base).
  const [user1_id, user2_id] = [user.id, recipientId].sort();

  const { data: existing } = await supabase
    .from("conversations")
    .select("id, status")
    .eq("user1_id", user1_id)
    .eq("user2_id", user2_id)
    .maybeSingle();

  if (existing) {
    if (existing.status === "closed") {
      return NextResponse.json(
        {
          error:
            "Cette conversation a déjà été clôturée et ne peut pas être rouverte.",
        },
        { status: 409 }
      );
    }
    return NextResponse.json({ conversationId: existing.id }, { status: 200 });
  }

  const { data: created, error } = await supabase
    .from("conversations")
    .insert({ user1_id, user2_id })
    .select("id")
    .single();

  if (error) {
    const message = error.message.includes("conversation active")
      ? "Vous avez déjà une conversation active. Clôturez-la avant d'en commencer une nouvelle."
      : "Impossible de démarrer la conversation.";
    return NextResponse.json({ error: message }, { status: 409 });
  }

  return NextResponse.json({ conversationId: created.id }, { status: 201 });
}

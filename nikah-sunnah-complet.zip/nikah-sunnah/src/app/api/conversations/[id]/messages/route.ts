import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { messageSchema } from "@/lib/validations";

export async function GET(
  _request: NextRequest,
  { params }: { params: { id: string } }
) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .eq("conversation_id", params.id)
    .order("created_at", { ascending: true });

  if (error) {
    return NextResponse.json({ error: "Erreur lors du chargement." }, { status: 400 });
  }

  // Marque comme lus les messages reçus (pas envoyés par moi)
  await supabase
    .from("messages")
    .update({ read_at: new Date().toISOString() })
    .eq("conversation_id", params.id)
    .neq("sender_id", user.id)
    .is("read_at", null);

  return NextResponse.json({ messages: data });
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const body = await request.json();
  const parsed = messageSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.errors[0]?.message ?? "Message invalide." },
      { status: 400 }
    );
  }

  const { data, error } = await supabase
    .from("messages")
    .insert({
      conversation_id: params.id,
      sender_id: user.id,
      content: parsed.data.content,
    })
    .select()
    .single();

  if (error) {
    // Les triggers SQL renvoient un message explicite (conversation clôturée,
    // limite quotidienne atteinte) qu'on relaie tel quel à l'utilisateur.
    const friendly =
      error.message.includes("clôturée") || error.message.includes("Limite de 3")
        ? error.message
        : "Impossible d'envoyer le message.";
    return NextResponse.json({ error: friendly }, { status: 400 });
  }

  return NextResponse.json({ message: data }, { status: 201 });
}

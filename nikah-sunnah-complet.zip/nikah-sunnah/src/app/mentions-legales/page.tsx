export const metadata = { title: "Mentions légales" };

export default function MentionsLegalesPage() {
  return (
    <div className="container-app max-w-3xl py-16">
      <h1 className="font-display text-3xl font-semibold text-ink">Mentions légales</h1>
      <p className="mt-2 text-sm italic text-ink/50">
        Modèle à compléter avec vos informations réelles et à faire valider
        par un professionnel du droit avant mise en production.
      </p>

      <div className="prose prose-sm mt-8 max-w-none text-ink/80">
        <h2>Éditeur du site</h2>
        <p>
          [Raison sociale], [forme juridique], au capital de [montant] €,
          immatriculée au RCS de [ville] sous le numéro [SIREN], dont le
          siège social est situé [adresse]. Numéro de TVA intracommunautaire :
          [numéro]. Directeur de la publication : [nom].
        </p>

        <h2>Hébergement</h2>
        <p>
          Le site est hébergé par Vercel Inc., 340 S Lemon Ave #4133, Walnut,
          CA 91789, États-Unis. La base de données et les fichiers sont
          hébergés par Supabase Inc.
        </p>

        <h2>Contact</h2>
        <p>
          Pour toute question, utilisez notre <a href="/contact">formulaire de contact</a>.
        </p>
      </div>
    </div>
  );
}

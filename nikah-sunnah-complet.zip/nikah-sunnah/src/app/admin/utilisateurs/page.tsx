import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { formatDateFr } from "@/lib/utils";
import { UserActions } from "@/components/admin/UserActions";

const statusTone: Record<string, "neutral" | "success" | "warning" | "danger"> = {
  pending_verification: "warning",
  active: "success",
  suspended: "warning",
  banned: "danger",
};

export default async function AdminUtilisateursPage() {
  const supabase = createClient();

  const { data: users } = await supabase
    .from("users")
    .select("id, email, role, status, created_at, profiles(first_name, gender)")
    .order("created_at", { ascending: false })
    .limit(200);

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Utilisateurs</h1>
      <p className="mt-1 text-sm text-ink/60">{users?.length ?? 0} compte(s).</p>

      <div className="mt-6 overflow-x-auto">
        <Card className="p-0">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-xs uppercase text-ink/40">
              <tr>
                <th className="px-4 py-3">Nom</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">Statut</th>
                <th className="px-4 py-3">Inscrit le</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {(users ?? []).map((u: any) => (
                <tr key={u.id}>
                  <td className="px-4 py-3">
                    {u.profiles?.[0]?.first_name ?? "—"}{" "}
                    {u.role === "admin" && <Badge tone="primary">Admin</Badge>}
                  </td>
                  <td className="px-4 py-3 text-ink/70">{u.email}</td>
                  <td className="px-4 py-3">
                    <Badge tone={statusTone[u.status] ?? "neutral"}>{u.status}</Badge>
                  </td>
                  <td className="px-4 py-3 text-ink/50">{formatDateFr(u.created_at)}</td>
                  <td className="px-4 py-3">
                    {u.role !== "admin" && <UserActions userId={u.id} status={u.status} />}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );
}

import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { formatDateFr } from "@/lib/utils";

export default async function AdminAbonnementsPage() {
  const supabase = createClient();

  const { data: subscriptions } = await supabase
    .from("subscriptions")
    .select("*, users:user_id(email)")
    .order("created_at", { ascending: false })
    .limit(200);

  const { data: boosts } = await supabase
    .from("boosts")
    .select("*, users:user_id(email)")
    .order("created_at", { ascending: false })
    .limit(50);

  return (
    <div className="space-y-10">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">
          Abonnements Premium
        </h1>
        <div className="mt-4 overflow-x-auto">
          <Card className="p-0">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-line text-xs uppercase text-ink/40">
                <tr>
                  <th className="px-4 py-3">Utilisateur</th>
                  <th className="px-4 py-3">Statut</th>
                  <th className="px-4 py-3">Fin de période</th>
                  <th className="px-4 py-3">Stripe</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {(subscriptions ?? []).map((s: any) => (
                  <tr key={s.id}>
                    <td className="px-4 py-3">{s.users?.email}</td>
                    <td className="px-4 py-3">
                      <Badge tone={s.status === "active" ? "success" : "neutral"}>
                        {s.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-ink/60">
                      {s.current_period_end ? formatDateFr(s.current_period_end) : "—"}
                    </td>
                    <td className="px-4 py-3 text-xs text-ink/40">
                      {s.stripe_subscription_id ?? "—"}
                    </td>
                  </tr>
                ))}
                {(!subscriptions || subscriptions.length === 0) && (
                  <tr>
                    <td colSpan={4} className="px-4 py-6 text-center text-ink/50">
                      Aucun abonnement pour le moment.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </Card>
        </div>
      </div>

      <div>
        <h2 className="font-display text-xl font-semibold text-ink">Boosts récents</h2>
        <div className="mt-4 overflow-x-auto">
          <Card className="p-0">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-line text-xs uppercase text-ink/40">
                <tr>
                  <th className="px-4 py-3">Utilisateur</th>
                  <th className="px-4 py-3">Statut</th>
                  <th className="px-4 py-3">Début</th>
                  <th className="px-4 py-3">Fin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {(boosts ?? []).map((b: any) => (
                  <tr key={b.id}>
                    <td className="px-4 py-3">{b.users?.email}</td>
                    <td className="px-4 py-3">
                      <Badge tone={b.status === "active" ? "success" : "neutral"}>
                        {b.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-ink/60">{formatDateFr(b.started_at)}</td>
                    <td className="px-4 py-3 text-ink/60">{formatDateFr(b.ends_at)}</td>
                  </tr>
                ))}
                {(!boosts || boosts.length === 0) && (
                  <tr>
                    <td colSpan={4} className="px-4 py-6 text-center text-ink/50">
                      Aucun boost pour le moment.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </Card>
        </div>
      </div>
    </div>
  );
}

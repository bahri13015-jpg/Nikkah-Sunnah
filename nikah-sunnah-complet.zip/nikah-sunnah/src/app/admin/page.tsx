import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";

export default async function AdminOverviewPage() {
  const supabase = createClient();

  const [
    { count: totalUsers },
    { count: pendingProfiles },
    { count: pendingReports },
    { count: activeSubscriptions },
    { count: bannedUsers },
  ] = await Promise.all([
    supabase.from("users").select("id", { count: "exact", head: true }),
    supabase
      .from("profiles")
      .select("id", { count: "exact", head: true })
      .eq("status", "pending"),
    supabase
      .from("reports")
      .select("id", { count: "exact", head: true })
      .eq("status", "pending"),
    supabase
      .from("subscriptions")
      .select("id", { count: "exact", head: true })
      .eq("plan", "premium")
      .eq("status", "active"),
    supabase
      .from("users")
      .select("id", { count: "exact", head: true })
      .eq("status", "banned"),
  ]);

  const stats = [
    { label: "Utilisateurs inscrits", value: totalUsers ?? 0, href: "/admin/utilisateurs" },
    { label: "Profils en attente", value: pendingProfiles ?? 0, href: "/admin/validation" },
    { label: "Signalements en attente", value: pendingReports ?? 0, href: "/admin/signalements" },
    { label: "Abonnés Premium actifs", value: activeSubscriptions ?? 0, href: "/admin/abonnements" },
    { label: "Comptes bannis", value: bannedUsers ?? 0, href: "/admin/utilisateurs" },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">
        Vue d'ensemble
      </h1>

      <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-3">
        {stats.map((s) => (
          <Link key={s.label} href={s.href}>
            <Card className="transition-shadow hover:shadow-md">
              <p className="text-3xl font-semibold text-primary">{s.value}</p>
              <p className="mt-1 text-sm text-ink/60">{s.label}</p>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}

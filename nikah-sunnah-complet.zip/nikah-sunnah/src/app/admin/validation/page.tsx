import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { calculateAge } from "@/lib/utils";
import { ValidationActions } from "@/components/admin/ValidationActions";

export default async function AdminValidationPage() {
  const supabase = createClient();

  const { data: profiles } = await supabase
    .from("profiles")
    .select("*, users:user_id(email)")
    .eq("status", "pending")
    .order("created_at", { ascending: true });

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">
        Validation des profils
      </h1>
      <p className="mt-1 text-sm text-ink/60">
        {profiles?.length ?? 0} profil(s) en attente.
      </p>

      <div className="mt-6 space-y-4">
        {(profiles ?? []).map((p: any) => (
          <Card key={p.id} className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="font-medium text-ink">
                {p.first_name}, {calculateAge(p.birth_date)} ans — {p.gender}
              </p>
              <p className="text-xs text-ink/50">
                {p.users?.email} · {[p.city, p.country].filter(Boolean).join(", ")}
              </p>
              {p.bio && <p className="mt-1 max-w-md text-sm text-ink/70">{p.bio}</p>}
            </div>
            <ValidationActions profileId={p.id} />
          </Card>
        ))}

        {(!profiles || profiles.length === 0) && (
          <p className="text-sm text-ink/50">Aucun profil en attente 🎉</p>
        )}
      </div>
    </div>
  );
}

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AdminNav } from "@/components/admin/AdminNav";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/connexion");

  const { data: appUser } = await supabase
    .from("users")
    .select("role")
    .eq("id", user.id)
    .single();

  if (appUser?.role !== "admin") {
    redirect("/tableau-de-bord");
  }

  return (
    <div className="flex min-h-screen flex-col bg-canvas md:flex-row">
      <AdminNav />
      <main className="container-app flex-1 py-8">{children}</main>
    </div>
  );
}

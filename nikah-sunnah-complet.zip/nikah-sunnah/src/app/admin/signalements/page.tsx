import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { formatDateFr } from "@/lib/utils";
import { ReportActions } from "@/components/admin/ReportActions";

export default async function AdminSignalementsPage() {
  const supabase = createClient();

  const { data: reports } = await supabase
    .from("reports")
    .select(
      "*, reporter:reporter_id(email), reported:reported_user_id(email, profiles(first_name, id))"
    )
    .eq("status", "pending")
    .order("created_at", { ascending: false });

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Signalements</h1>
      <p className="mt-1 text-sm text-ink/60">{reports?.length ?? 0} en attente.</p>

      <div className="mt-6 space-y-4">
        {(reports ?? []).map((r: any) => (
          <Card key={r.id}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <Badge tone="warning">{r.reason}</Badge>
                <p className="mt-2 text-sm text-ink">
                  Signalé : <span className="font-medium">{r.reported?.profiles?.[0]?.first_name ?? r.reported?.email}</span>
                </p>
                <p className="text-xs text-ink/50">Par {r.reporter?.email} · {formatDateFr(r.created_at)}</p>
                {r.description && <p className="mt-2 max-w-lg text-sm text-ink/70">{r.description}</p>}
              </div>
              <ReportActions reportId={r.id} />
            </div>
          </Card>
        ))}

        {(!reports || reports.length === 0) && (
          <p className="text-sm text-ink/50">Aucun signalement en attente.</p>
        )}
      </div>
    </div>
  );
}

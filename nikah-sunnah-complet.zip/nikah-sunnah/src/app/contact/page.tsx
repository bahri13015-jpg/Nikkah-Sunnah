"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { contactSchema } from "@/lib/validations";
import type { z } from "zod";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Textarea } from "@/components/ui/Textarea";
import { Label } from "@/components/ui/Label";
import { Button } from "@/components/ui/Button";

type FormValues = z.infer<typeof contactSchema>;

export default function ContactPage() {
  const [sent, setSent] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(contactSchema) });

  const onSubmit = async (data: FormValues) => {
    setServerError(null);
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      setServerError("Une erreur est survenue. Réessayez plus tard.");
      return;
    }
    setSent(true);
  };

  return (
    <div className="container-app flex min-h-screen items-center justify-center py-16">
      <Card className="w-full max-w-lg">
        <h1 className="font-display text-2xl font-semibold text-ink">Contact</h1>
        <p className="mt-1 text-sm text-ink/60">
          Une question, un problème ? Écrivez-nous.
        </p>

        {sent ? (
          <p className="mt-6 rounded-lg bg-success/10 px-3 py-2 text-sm text-success">
            Message envoyé ✓ Nous vous répondrons rapidement.
          </p>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4">
            <div>
              <Label htmlFor="name">Nom</Label>
              <Input id="name" {...register("name")} error={errors.name?.message} />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" {...register("email")} error={errors.email?.message} />
            </div>
            <div>
              <Label htmlFor="subject">Sujet</Label>
              <Input id="subject" {...register("subject")} error={errors.subject?.message} />
            </div>
            <div>
              <Label htmlFor="message">Message</Label>
              <Textarea id="message" rows={5} {...register("message")} error={errors.message?.message} />
            </div>
            {serverError && <p className="text-sm text-danger">{serverError}</p>}
            <Button type="submit" className="w-full" isLoading={isSubmitting}>
              Envoyer
            </Button>
          </form>
        )}
      </Card>
    </div>
  );
}

import Link from "next/link";
import { ShieldCheck, MessageCircleHeart, Users } from "lucide-react";
import { Button } from "@/components/ui/Button";

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col bg-canvas">
      <header className="container-app flex h-20 items-center justify-between">
        <span className="font-display text-xl font-semibold text-primary">
          Nikah Sunnah
        </span>
        <nav className="flex items-center gap-3">
          <Link href="/connexion" className="text-sm font-medium text-ink/70">
            Connexion
          </Link>
          <Link href="/inscription">
            <Button size="sm">S'inscrire</Button>
          </Link>
        </nav>
      </header>

      <main className="flex-1">
        <section className="container-app py-16 text-center sm:py-24">
          <h1 className="mx-auto max-w-2xl font-display text-4xl font-semibold leading-tight text-ink sm:text-5xl">
            Une rencontre <span className="text-primary">sérieuse</span>, en vue
            du <span className="text-primary">mariage</span>
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-ink/60">
            La plateforme matrimoniale pour musulmans et musulmanes
            francophones, dans le respect des valeurs islamiques. Profils
            vérifiés, échanges encadrés, une seule conversation à la fois.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link href="/inscription/homme">
              <Button size="lg">Je suis un homme</Button>
            </Link>
            <Link href="/inscription/femme">
              <Button size="lg" variant="secondary">
                Je suis une femme
              </Button>
            </Link>
          </div>
        </section>

        <section className="container-app grid grid-cols-1 gap-6 pb-20 sm:grid-cols-3">
          {[
            {
              icon: ShieldCheck,
              title: "Profils validés",
              text: "Chaque profil est vérifié manuellement par notre équipe avant d'être visible.",
            },
            {
              icon: MessageCircleHeart,
              title: "Messagerie halal",
              text: "Une seule conversation active à la fois, pour une démarche sérieuse et respectueuse.",
            },
            {
              icon: Users,
              title: "Communauté francophone",
              text: "Des musulmans et musulmanes du monde entier, engagés dans une recherche sincère.",
            },
          ].map(({ icon: Icon, title, text }) => (
            <div key={title} className="rounded-2xl border border-line bg-white p-6">
              <Icon className="text-primary" size={24} />
              <h3 className="mt-3 font-display text-lg font-semibold text-ink">
                {title}
              </h3>
              <p className="mt-1 text-sm text-ink/60">{text}</p>
            </div>
          ))}
        </section>
      </main>

      <footer className="border-t border-line py-8">
        <div className="container-app flex flex-col items-center justify-between gap-4 text-sm text-ink/50 sm:flex-row">
          <p>© {new Date().getFullYear()} Nikah Sunnah</p>
          <div className="flex gap-4">
            <Link href="/contact">Contact</Link>
            <Link href="/mentions-legales">Mentions légales</Link>
            <Link href="/politique-confidentialite">Confidentialité</Link>
            <Link href="/cgu">CGU</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

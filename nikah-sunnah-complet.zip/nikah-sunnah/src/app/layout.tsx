import type { Metadata } from "next";
import { Fraunces, Inter } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["500", "600", "700"],
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Nikah Sunnah — Rencontres sérieuses en vue du mariage",
    template: "%s — Nikah Sunnah",
  },
  description:
    "Plateforme de mise en relation pour musulmans et musulmanes engagés dans une démarche sérieuse de mariage, dans le respect de la sunnah.",
  openGraph: {
    title: "Nikah Sunnah",
    description:
      "Plateforme matrimoniale islamique sérieuse, francophone, à la recherche d'un mariage selon la sunnah.",
    url: siteUrl,
    siteName: "Nikah Sunnah",
    locale: "fr_FR",
    type: "website",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" className={`${fraunces.variable} ${inter.variable}`}>
      <body className="min-h-screen font-sans">{children}</body>
    </html>
  );
}

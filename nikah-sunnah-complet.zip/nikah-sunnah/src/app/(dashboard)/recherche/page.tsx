import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { ProfileCard } from "@/components/search/ProfileCard";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/Label";
import { Button } from "@/components/ui/Button";

export default async function RecherchePage({
  searchParams,
}: {
  searchParams: { ville?: string; ageMin?: string; ageMax?: string };
}) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/connexion");

  const { data: myProfile } = await supabase
    .from("profiles")
    .select("gender")
    .eq("user_id", user.id)
    .single();

  if (!myProfile) redirect("/tableau-de-bord");

  const oppositeGender = myProfile.gender === "homme" ? "femme" : "homme";

  let query = supabase
    .from("profiles")
    .select("id, first_name, birth_date, city, country, profession, photo_url, is_boosted, boosted_until")
    .eq("gender", oppositeGender)
    .eq("status", "approved")
    .order("is_boosted", { ascending: false })
    .order("created_at", { ascending: false });

  if (searchParams.ville) {
    query = query.ilike("city", `%${searchParams.ville}%`);
  }

  const { data: profiles } = await query;

  const now = Date.now();
  const withEffectiveBoost = (profiles ?? []).map((p: any) => ({
    ...p,
    is_boosted: !!(p.is_boosted && p.boosted_until && new Date(p.boosted_until).getTime() > now),
  }));
  withEffectiveBoost.sort((a, b) => Number(b.is_boosted) - Number(a.is_boosted));

  const ageMin = searchParams.ageMin ? Number(searchParams.ageMin) : undefined;
  const ageMax = searchParams.ageMax ? Number(searchParams.ageMax) : undefined;

  const filtered = withEffectiveBoost.filter((p) => {
    if (!ageMin && !ageMax) return true;
    const age =
      new Date().getFullYear() - new Date(p.birth_date).getFullYear();
    if (ageMin && age < ageMin) return false;
    if (ageMax && age > ageMax) return false;
    return true;
  });

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Recherche</h1>
      <p className="mt-1 text-sm text-ink/60">
        Profils {oppositeGender === "femme" ? "féminins" : "masculins"} validés
        par notre équipe.
      </p>

      <form className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4" method="GET">
        <div className="col-span-2 sm:col-span-1">
          <Label htmlFor="ville">Ville</Label>
          <Input id="ville" name="ville" defaultValue={searchParams.ville} />
        </div>
        <div>
          <Label htmlFor="ageMin">Âge min.</Label>
          <Input id="ageMin" name="ageMin" type="number" min={18} defaultValue={searchParams.ageMin} />
        </div>
        <div>
          <Label htmlFor="ageMax">Âge max.</Label>
          <Input id="ageMax" name="ageMax" type="number" min={18} defaultValue={searchParams.ageMax} />
        </div>
        <div className="flex items-end">
          <Button type="submit" variant="outline" className="w-full">
            Filtrer
          </Button>
        </div>
      </form>

      {filtered.length === 0 ? (
        <p className="mt-12 text-center text-sm text-ink/50">
          Aucun profil ne correspond à votre recherche pour le moment.
        </p>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {filtered.map((p) => (
            <ProfileCard key={p.id} profile={p} />
          ))}
        </div>
      )}
    </div>
  );
}

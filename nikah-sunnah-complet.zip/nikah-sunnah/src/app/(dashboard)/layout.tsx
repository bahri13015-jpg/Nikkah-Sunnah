import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { DashboardNav } from "@/components/layout/DashboardNav";
import { Card } from "@/components/ui/Card";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/connexion");
  }

  const { data: appUser } = await supabase
    .from("users")
    .select("status")
    .eq("id", user.id)
    .single();

  const { data: profile } = await supabase
    .from("profiles")
    .select("id")
    .eq("user_id", user.id)
    .single();

  const { data: subscription } = await supabase
    .from("subscriptions")
    .select("plan, status")
    .eq("user_id", user.id)
    .eq("status", "active")
    .maybeSingle();

  if (appUser?.status === "banned" || appUser?.status === "suspended") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-canvas px-4">
        <Card className="max-w-md text-center">
          <h1 className="font-display text-xl font-semibold text-danger">
            Compte {appUser.status === "banned" ? "banni" : "suspendu"}
          </h1>
          <p className="mt-2 text-sm text-ink/60">
            Votre compte ne peut pas accéder à la plateforme actuellement.
            Contactez le support si vous pensez qu'il s'agit d'une erreur.
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-canvas">
      <DashboardNav
        profileId={profile?.id ?? user.id}
        isPremium={subscription?.plan === "premium"}
      />
      <main className="container-app py-8">{children}</main>
    </div>
  );
}

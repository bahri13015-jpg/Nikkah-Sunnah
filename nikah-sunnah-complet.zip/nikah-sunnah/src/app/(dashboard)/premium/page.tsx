import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { UpgradeButtons } from "@/components/profile/UpgradeButtons";

export default async function PremiumPage({
  searchParams,
}: {
  searchParams: { success?: string; boost?: string; canceled?: string };
}) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/connexion");

  const { data: subscription } = await supabase
    .from("subscriptions")
    .select("plan, status, current_period_end")
    .eq("user_id", user.id)
    .eq("status", "active")
    .maybeSingle();

  const isPremium = subscription?.plan === "premium";

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-2xl font-semibold text-ink">
        Premium &amp; Boost
      </h1>
      <p className="mt-1 text-sm text-ink/60">
        Soutenez la plateforme et augmentez vos chances de trouver votre
        moitié.
      </p>

      {searchParams.success && (
        <p className="mt-4 rounded-lg bg-success/10 px-3 py-2 text-sm text-success">
          Merci, votre abonnement Premium est en cours d'activation ✓
        </p>
      )}
      {searchParams.boost && (
        <p className="mt-4 rounded-lg bg-success/10 px-3 py-2 text-sm text-success">
          Merci, votre profil va être mis en avant ✓
        </p>
      )}
      {searchParams.canceled && (
        <p className="mt-4 rounded-lg bg-canvas2 px-3 py-2 text-sm text-ink/60">
          Paiement annulé.
        </p>
      )}

      <div className="mt-8">
        <UpgradeButtons isPremium={isPremium} />
      </div>
    </div>
  );
}

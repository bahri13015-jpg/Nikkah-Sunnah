import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { MessagingApp } from "@/components/messaging/MessagingApp";

export default async function MessagesPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/connexion");

  const { data: conversations } = await supabase
    .from("conversations")
    .select("id, status, last_message_at, created_at, user1_id, user2_id, closed_at")
    .or(`user1_id.eq.${user.id},user2_id.eq.${user.id}`)
    .order("status", { ascending: true })
    .order("last_message_at", { ascending: false, nullsFirst: false });

  const counterpartIds = (conversations ?? []).map((c) =>
    c.user1_id === user.id ? c.user2_id : c.user1_id
  );

  const { data: profiles } = counterpartIds.length
    ? await supabase
        .from("profiles")
        .select("id, user_id, first_name, photo_url")
        .in("user_id", counterpartIds)
    : { data: [] };

  const conversationsWithProfile = (conversations ?? []).map((c) => {
    const counterpartId = c.user1_id === user.id ? c.user2_id : c.user1_id;
    const profile = profiles?.find((p) => p.user_id === counterpartId);
    return { ...c, counterpart: profile ?? null };
  });

  let initialMessages: any[] = [];
  const activeConversation = conversationsWithProfile.find((c) => c.status === "active");
  if (activeConversation) {
    const { data } = await supabase
      .from("messages")
      .select("*")
      .eq("conversation_id", activeConversation.id)
      .order("created_at", { ascending: true });
    initialMessages = data ?? [];
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Messages</h1>
      <p className="mt-1 text-sm text-ink/60">
        Une seule conversation active à la fois — clôturez-la pour en commencer
        une nouvelle.
      </p>

      <div className="mt-6">
        <MessagingApp
          currentUserId={user.id}
          conversations={conversationsWithProfile}
          initialActiveId={activeConversation?.id ?? null}
          initialMessages={initialMessages}
        />
      </div>
    </div>
  );
}

import { notFound, redirect } from "next/navigation";
import { MapPin, Briefcase, GraduationCap, Heart, BookOpen } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { calculateAge } from "@/lib/utils";
import { ProfileEditForm } from "@/components/profile/ProfileEditForm";
import { ContactButton } from "@/components/profile/ContactButton";
import { FavoriteButton } from "@/components/profile/FavoriteButton";
import { ReportButton } from "@/components/profile/ReportButton";

export default async function ProfilPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/connexion");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", params.id)
    .maybeSingle();

  if (!profile) notFound();

  const isOwnProfile = profile.user_id === user.id;

  if (!isOwnProfile && profile.status !== "approved") {
    notFound();
  }

  if (isOwnProfile) {
    return (
      <div className="mx-auto max-w-2xl">
        <h1 className="font-display text-2xl font-semibold text-ink">Mon profil</h1>

        <div className="mt-2 flex items-center gap-2">
          {profile.status === "pending" && (
            <Badge tone="warning">En attente de validation</Badge>
          )}
          {profile.status === "approved" && <Badge tone="success">Profil validé</Badge>}
          {profile.status === "rejected" && (
            <Badge tone="danger">
              Profil refusé{profile.rejection_reason ? ` — ${profile.rejection_reason}` : ""}
            </Badge>
          )}
          {profile.is_boosted && <Badge tone="primary">Boosté ✨</Badge>}
        </div>

        <Card className="mt-4">
          <ProfileEditForm profile={profile} />
        </Card>
      </div>
    );
  }

  const { data: existingConversation } = await supabase
    .from("conversations")
    .select("id, status")
    .or(
      `and(user1_id.eq.${user.id},user2_id.eq.${profile.user_id}),and(user1_id.eq.${profile.user_id},user2_id.eq.${user.id})`
    )
    .maybeSingle();

  const { data: favorite } = await supabase
    .from("favorites")
    .select("id")
    .eq("user_id", user.id)
    .eq("favorited_user_id", profile.user_id)
    .maybeSingle();

  return (
    <div className="mx-auto max-w-2xl">
      <Card className="overflow-hidden p-0">
        <div className="aspect-[4/3] bg-canvas2">
          {profile.photo_url ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={profile.photo_url}
              alt={profile.first_name}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center font-display text-5xl text-primary/30">
              {profile.first_name.charAt(0)}
            </div>
          )}
        </div>

        <div className="p-6">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h1 className="font-display text-2xl font-semibold text-ink">
                {profile.first_name}, {calculateAge(profile.birth_date)} ans
              </h1>
              {(profile.city || profile.country) && (
                <p className="mt-1 flex items-center gap-1 text-sm text-ink/60">
                  <MapPin size={14} />
                  {[profile.city, profile.country].filter(Boolean).join(", ")}
                </p>
              )}
            </div>
            {profile.is_boosted && <Badge tone="primary">Mis en avant</Badge>}
          </div>

          <dl className="mt-5 grid grid-cols-1 gap-3 text-sm sm:grid-cols-2">
            {profile.profession && (
              <div className="flex items-center gap-2 text-ink/70">
                <Briefcase size={15} className="text-primary" />
                {profile.profession}
              </div>
            )}
            {profile.education_level && (
              <div className="flex items-center gap-2 text-ink/70">
                <GraduationCap size={15} className="text-primary" />
                {profile.education_level}
              </div>
            )}
            {profile.religious_practice && (
              <div className="flex items-center gap-2 text-ink/70">
                <BookOpen size={15} className="text-primary" />
                {profile.religious_practice}
              </div>
            )}
            {profile.marital_status && (
              <div className="flex items-center gap-2 text-ink/70">
                <Heart size={15} className="text-primary" />
                {profile.marital_status}
              </div>
            )}
          </dl>

          {profile.bio && (
            <div className="mt-5">
              <h2 className="text-sm font-semibold text-ink">À propos</h2>
              <p className="mt-1 whitespace-pre-line text-sm text-ink/70">{profile.bio}</p>
            </div>
          )}

          {profile.looking_for && (
            <div className="mt-5">
              <h2 className="text-sm font-semibold text-ink">Profil recherché</h2>
              <p className="mt-1 whitespace-pre-line text-sm text-ink/70">
                {profile.looking_for}
              </p>
            </div>
          )}

          <div className="mt-6 flex flex-wrap gap-2">
            <ContactButton
              recipientId={profile.user_id}
              existingConversationId={existingConversation?.id}
              existingStatus={existingConversation?.status}
            />
            <FavoriteButton
              favoritedUserId={profile.user_id}
              initialIsFavorite={!!favorite}
            />
            <ReportButton reportedUserId={profile.user_id} />
          </div>
        </div>
      </Card>
    </div>
  );
}

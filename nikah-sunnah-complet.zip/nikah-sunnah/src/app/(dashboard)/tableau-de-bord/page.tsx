import Link from "next/link";
import { redirect } from "next/navigation";
import { Heart, MessageCircle, Search, Sparkles } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { ProfileCard } from "@/components/search/ProfileCard";

export default async function TableauDeBordPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/connexion");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("user_id", user.id)
    .single();

  if (!profile) redirect("/inscription");

  const { count: favoritesCount } = await supabase
    .from("favorites")
    .select("id", { count: "exact", head: true })
    .eq("user_id", user.id);

  const { count: unreadCount } = await supabase
    .from("messages")
    .select("id", { count: "exact", head: true })
    .neq("sender_id", user.id)
    .is("read_at", null);

  const { data: rawSuggestions } = await supabase
    .from("profiles")
    .select("id, first_name, birth_date, city, country, profession, photo_url, is_boosted, boosted_until")
    .eq("gender", profile.gender === "homme" ? "femme" : "homme")
    .eq("status", "approved")
    .limit(8);

  const now = Date.now();
  const suggestions = (rawSuggestions ?? [])
    .map((p) => ({
      ...p,
      is_boosted: !!(p.is_boosted && p.boosted_until && new Date(p.boosted_until).getTime() > now),
    }))
    .sort((a, b) => Number(b.is_boosted) - Number(a.is_boosted))
    .slice(0, 4);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">
          Assalamu alaykum, {profile.first_name} 👋
        </h1>
        <div className="mt-2">
          {profile.status === "pending" && (
            <Badge tone="warning">Votre profil est en attente de validation</Badge>
          )}
          {profile.status === "approved" && (
            <Badge tone="success">Votre profil est validé et visible</Badge>
          )}
          {profile.status === "rejected" && (
            <Badge tone="danger">Votre profil a été refusé — modifiez-le</Badge>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Card className="text-center">
          <MessageCircle className="mx-auto text-primary" size={20} />
          <p className="mt-2 text-2xl font-semibold text-ink">{unreadCount ?? 0}</p>
          <p className="text-xs text-ink/50">Messages non lus</p>
        </Card>
        <Card className="text-center">
          <Heart className="mx-auto text-primary" size={20} />
          <p className="mt-2 text-2xl font-semibold text-ink">{favoritesCount ?? 0}</p>
          <p className="text-xs text-ink/50">Favoris</p>
        </Card>
        <Card className="text-center">
          <Sparkles className="mx-auto text-primary" size={20} />
          <p className="mt-2 text-2xl font-semibold text-ink">
            {profile.is_boosted ? "Actif" : "—"}
          </p>
          <p className="text-xs text-ink/50">Boost</p>
        </Card>
        <Link href="/recherche">
          <Card className="flex h-full flex-col items-center justify-center text-center transition-shadow hover:shadow-md">
            <Search className="text-primary" size={20} />
            <p className="mt-2 text-sm font-medium text-primary">Rechercher</p>
          </Card>
        </Link>
      </div>

      {!profile.bio && (
        <Card className="border-accent/40 bg-accent/5">
          <p className="text-sm text-ink">
            Votre profil est incomplet.{" "}
            <Link href={`/profil/${profile.id}`} className="font-medium text-primary underline">
              Ajoutez une description et vos critères
            </Link>{" "}
            pour augmenter vos chances de match.
          </p>
        </Card>
      )}

      <div>
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-ink">
            Profils suggérés
          </h2>
          <Link href="/recherche" className="text-sm text-primary">
            Voir tout
          </Link>
        </div>
        {suggestions && suggestions.length > 0 ? (
          <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {suggestions.map((p) => (
              <ProfileCard key={p.id} profile={p} />
            ))}
          </div>
        ) : (
          <p className="mt-4 text-sm text-ink/50">
            Aucune suggestion pour le moment.
          </p>
        )}
      </div>
    </div>
  );
}

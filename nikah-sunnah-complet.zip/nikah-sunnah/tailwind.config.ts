import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Palette du projet — à utiliser exclusivement via ces tokens (pas de hex en dur dans les composants)
        ink: "#1C1B17",          // texte principal
        canvas: "#FAF6EF",       // fond de page, ivoire chaud
        canvas2: "#F1EADC",      // fond secondaire (cards, sections alternées)
        primary: {
          DEFAULT: "#1F4D3D",    // vert profond, couleur de marque
          light: "#2E6B55",
          dark: "#143329",
        },
        accent: {
          DEFAULT: "#C9A227",    // or/ambre, accents et CTA secondaires
          light: "#E0C158",
        },
        clay: "#B5603F",         // terracotta, alertes douces / badges
        line: "#E4DCCB",         // bordures, séparateurs
        success: "#2E7D32",
        warning: "#B5603F",
        danger: "#B3261E",
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        sans: ["var(--font-sans)", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      borderRadius: {
        xl: "1rem",
        "2xl": "1.5rem",
      },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};

export default config;
